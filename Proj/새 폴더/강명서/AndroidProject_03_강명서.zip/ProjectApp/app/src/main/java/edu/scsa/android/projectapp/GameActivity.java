package edu.scsa.android.projectapp;

import java.util.Random;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.content.ContextCompat;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class GameActivity  extends Activity {
    FrameLayout f;
    FrameLayout.LayoutParams params;
    int count=0;   //잡은 쥐 개수를 저장할 변수
    int score=0;   //점수를 저장할 변수
    int delay=1200;  // 게임 속도 조절
    static boolean threadEndFlag=true; // 쓰레드 끄기
    MouseTask mt;				// 쓰레드 구현

    int myWidth;  // 내 폰의 너비
    int myHeight; // 내 폰의 높이
    int imgWidth=150;  //그림 크기
    int imgHeight=150;//그림 크기
    Random r=new Random();  // 이미지 위치를 랜덤하게 발생시킬 객체

    SoundPool pool;   // 소리
    int eatcookie;    // 소리
    int eatstone;     // 소리
    MediaPlayer mp;   // 소리

    int x=200;        //시작위치
    int y=200;        //시작위치
    ImageView[] imgs; // 이미지들을 담아 놓을 배열
    ImageView[] simgs; // 돌을 담을 배열
    ImageView[] bimgs;

    int level=1;      // 게임 레벨
    int nums=0;

    Random generator; //랜덤 숫자 생성용
    TextView scoreV;
    TextView stageV;
    Toast stagetoast;

    AlertDialog.Builder alertDialog; //알림창용
    AlertDialog myD;
    TextView title;
    TextView msg;
    Button oneB;
    Button twoB;
    private int mode;
    private boolean bonusmode = true;
    final int GAME_OVER = 0;
    final int NEXT_STAGE = 1;
    final int BONUS_MODE = 2;
    int cookiesu = 7;
    int bonussu = 1;

    NfcAdapter nfcAdapter; //NFC
    PendingIntent pIntent;
    Intent i;
    IntentFilter[] filters;
    TextView bonusV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_game);
        setTitle("Mouse Chaser");

        f=(FrameLayout) findViewById(R.id.frame);
        params=new FrameLayout.LayoutParams(1, 1);

        //디스플레이 크기 체크
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        myWidth=metrics.widthPixels;
        myHeight=metrics.heightPixels;
        Log.d("game","My Window "+myWidth+" : "+myHeight);

        //사운드 셋팅
        pool = new SoundPool(1, AudioManager.STREAM_MUSIC, 0);
        eatcookie = pool.load(this, R.raw.cookie_sound, 1);
        eatstone = pool.load(this, R.raw.stone_sound, 1);
        mp=MediaPlayer.create(this, R.raw.bgm);
        mp.setLooping(true);

        //랜덤 객체
        generator = new Random();

        //점수판
        scoreV = findViewById(R.id.score);
        scoreV.setText(String.format("SCORE : " + "%02d", score));
        stageV = findViewById(R.id.stage);
        bonusV = findViewById(R.id.bonus);

        //알림창
        init_AlertDialog();

        //NFC
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        i = new Intent(this, this.getClass());
        i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        pIntent =
                PendingIntent.getActivity(this, 0, i, 0);
        IntentFilter tagFilter =
                new IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED);
        filters = new IntentFilter[]{tagFilter};

        init(cookiesu);
    }


    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        Log.e("INFO", "NFC");
        String action = i.getAction();

        if (bonusmode) {

            Parcelable[] rawData = i.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);
            NdefMessage ndefM = (NdefMessage) rawData[0];
            NdefRecord[] recArr = ndefM.getRecords();
            NdefRecord textR = recArr[0];
            byte[] recT = textR.getType();
            String strT = new String(recT);
            Log.i("INFO", "type: " + strT);
            byte[] bData = textR.getPayload();
            String sData = "Not initialized";
            if(strT.equals(("T")))
            {
                sData = new String(bData, 3, bData.length - 3);

                try
                {
                    bonussu = Integer.parseInt(sData);
                }
                catch (NumberFormatException e)
                {
                    Toast.makeText(this, "쿠폰 형식 틀림",Toast.LENGTH_SHORT).show();
                    return;
                }

                if(bonussu<=0 || bonussu>1000)
                {
                    Toast.makeText(this, "쿠폰 형식 틀림",Toast.LENGTH_SHORT).show();
                    return;
                }
            }
            else
            {
                Toast.makeText(this, "쿠폰 형식 틀림",Toast.LENGTH_SHORT).show();
                return;
            }

            mode = BONUS_MODE;
            Alert("BONUS CHANCE!", "accept", "refuse");
        }
    }

    private void init_AlertDialog()
    {
        //선언
        alertDialog = new AlertDialog.Builder(this);
        alertDialog.setCancelable(false);

        //타이틀 텍스트뷰
        title = new TextView(this);
        title.setTextColor(ContextCompat.getColor(this, android.R.color.black));
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        //lp.setMargins(0, 0, 0, 150);
        title.setPadding(0,70,0,0);
        title.setLayoutParams(lp);
        title.setText("STAGE 1");
        title.setGravity(Gravity.CENTER);

        alertDialog.setCustomTitle(title);

        //내용 텍스트뷰
        msg = new TextView(this);
        msg.setText("Eat Cookies!");
        msg.setTextColor(ContextCompat.getColor(this, android.R.color.holo_purple));
        msg.setTextSize(TypedValue.COMPLEX_UNIT_SP,16);
        msg.setGravity(Gravity.CENTER);
        msg.setPadding(0,70,0,0);

        alertDialog.setView(msg);

        //버튼
        alertDialog.setNegativeButton("start", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                switch(mode)
                {
                    case GAME_OVER: bonusV.setText("1 BONUS");
                                    scoreV.setText("SCORE : 00");
                                    score = 0; cookiesu = 7; level=1;
                                    bonusmode=true; init(cookiesu); break;
                    case NEXT_STAGE : init(cookiesu); break;
                    case BONUS_MODE : bonusV.setText("0 BONUS");
                                      make_bonus(); break;
                }
                return;
            }
        });

        alertDialog.setPositiveButton("cancel", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                if(mode==BONUS_MODE)
                {
                    return;
                }
                else
                {
                    finish();
                }
               return;
            }
        });


        //Dialog생성 - button
        myD = alertDialog.create();
        myD.show();

        myD.getWindow().setLayout(1100, 700);

        oneB = myD.getButton(AlertDialog.BUTTON_NEGATIVE);
        twoB = myD.getButton(AlertDialog.BUTTON_POSITIVE);

        //oneB.setTypeface(Typeface.DEFAULT_BOLD);
        //twoB.setTypeface(Typeface.DEFAULT_BOLD);

        LinearLayout.LayoutParams lp2 = (LinearLayout.LayoutParams) twoB.getLayoutParams();
        lp2.weight = 10;
        lp2.bottomMargin = -10;

        oneB.setLayoutParams(lp2);
        twoB.setLayoutParams(lp2);
    }

    private void make_bonus()
    {
        int su = bonussu; //이거 nfc에서 받아오자.
        count -= su;
        bimgs=new ImageView[su];
        for(int i=0; i<su; i++)
        {
            ImageView iv = new ImageView(this);
            int k = generator.nextInt(4);
            switch (k) {
                case 0:
                    iv.setImageResource(R.drawable.cookie_1);  // 이미지 소스 설정
                    break;
                case 1:
                    iv.setImageResource(R.drawable.cookie_2);  // 이미지 소스 설정
                    break;
                case 2:
                    iv.setImageResource(R.drawable.cookie_3);  // 이미지 소스 설정
                    break;
                case 3:
                    iv.setImageResource(R.drawable.cookie_4);  // 이미지 소스 설정
                    break;
            }
            iv.setTag("cookie");
            f.addView(iv, params);  // 화면에 표시
            bimgs[i] = iv;     // 배열에 담기
            iv.setOnClickListener(h);  // 이벤트 등록

            bonusmode=false;
            }
        return;
    }

    public void Alert(String Title, String one, String two)
    {
        title.setText(Title);
        msg.setText("Your score : "+Integer.toString(score));
        if(mode==BONUS_MODE)
        {
            msg.setText("You won "+Integer.toString(bonussu)+" cookies coupon!");
        }
        oneB.setText(one);
        twoB.setText(two);

        myD.show();
    }

    public void init(int nums){
        //초기화
        count=0;
        threadEndFlag=true;
        this.nums=nums;
        delay=(int)(delay*(10-(level*0.7))/10.);

        stageV.setText(String.format("STAGE " + level));

        f.removeAllViews();

        //이미지 담을 배열 생성과 이미지 담기 - 쿠키
        imgs=new ImageView[nums];
        for(int i=0; i<nums; i++){
            ImageView iv=new ImageView(this);
            int k = generator.nextInt(4);

            switch(k)
            {
                case 0: iv.setImageResource(R.drawable.cookie_1);  // 이미지 소스 설정
                    break;
                case 1: iv.setImageResource(R.drawable.cookie_2);  // 이미지 소스 설정
                    break;
                case 2: iv.setImageResource(R.drawable.cookie_3);  // 이미지 소스 설정
                    break;
                case 3: iv.setImageResource(R.drawable.cookie_4);  // 이미지 소스 설정
                    break;
            }
            iv.setTag("cookie");
            f.addView(iv, params);  // 화면에 표시
            imgs[i]=iv;     // 배열에 담기
            iv.setOnClickListener(h);  // 이벤트 등록

//            //stage 표시
//            stagetoast = Toast.makeText(GameActivity.this,
//                    "  STAGE "+Integer.toString(level)+"!  ", Toast.LENGTH_SHORT);
//            stagetoast.setGravity(Gravity.TOP, 0, 30);
//            stagetoast.show();


        }

        //돌 관련
        int su = level*3;
        simgs=new ImageView[su];
        for(int k=0;k<su;k++)
        {
            ImageView iv2=new ImageView(this);
            iv2.setImageResource(R.drawable.stone_1);
            iv2.setTag("stone");
            f.addView(iv2, params);
            simgs[k]=iv2;
            iv2.setOnClickListener(h);
        }

        mt=new MouseTask();  //일정 간격으로 이미지 위치를 바꿀 쓰레드 실행
        mt.execute();

    }
    protected void onResume() {
        super.onResume();
        nfcAdapter.enableForegroundDispatch
                (this, pIntent, filters,null);
        mp.start();
    };
    protected void onPause() {
        super.onPause();
        nfcAdapter.disableForegroundDispatch(this);
        mp.pause();
    };

    protected void onDestroy() {
        super.onDestroy();
        mp.release();
        mt.cancel(true);
        threadEndFlag = false;
    };

    View.OnClickListener  h=new View.OnClickListener()
    {
        public void onClick(View v) {   // 아이템 클릭 시

            ImageView iv = (ImageView) v;

            if (((String)iv.getTag()).equals("cookie"))
            {
                //먹은 쿠키 수
                count++;
                score+=3;
                scoreV.setText(String.format("SCORE : " + "%02d", score));
                //소리내기
                pool.play(eatcookie, 1, 1, 0, 0, 1);
            }
            else
            {
                //점수
                score-=5;
                if(score>=0)
                {
                    scoreV.setText(String.format("SCORE : " + "%02d", score));
                }
                else
                {
                    scoreV.setText(String.format("SCORE : " + "%02d", 0));
                }

                //소리내기
                pool.play(eatstone, 1, 1, 0, 0, 1);
            }

            iv.setVisibility(View.INVISIBLE); // 이미지(쿠키, 돌) 제거

            if(score<0)
            {
                score=0;
                mode = GAME_OVER;
                Alert("Game over","again","finish");
            }

            // 쿠키 다 먹었을 때
            if (count == nums) {
                threadEndFlag = false;
                mt.cancel(true);

                if(level<=4)
                {
                    level++;
                    cookiesu+=2;
                    mode=NEXT_STAGE;
                    Alert(Integer.toString(level-1)+" STAGE CLEAR!",
                            Integer.toString(level)+" stage","finish");
                }

                if(level==5)
                {
                    mode=GAME_OVER;
                    Alert("GAME CLEAR!","again","finish");
                }
            }
        }
    };

    // 쥐 위치 이동하여 다시 그리기
    public void update()
    {
        if(!threadEndFlag) return;

        Log.d("game", "update:");
        for(ImageView img:imgs){
            x=r.nextInt(myWidth-imgWidth);
            y=r.nextInt(myHeight-imgHeight);

            img.layout(x, y, x+imgWidth, y+imgHeight);
            img.invalidate();
        }

        for(ImageView img:simgs)
        {
            x=r.nextInt(myWidth-imgWidth);
            y=r.nextInt(myHeight-imgHeight);

            img.layout(x, y, x+imgWidth, y+imgHeight);
            img.invalidate();
        }

        if(bonusmode==false)
        {
            for(ImageView img:bimgs)
            {
                x=r.nextInt(myWidth-imgWidth);
                y=r.nextInt(myHeight-imgHeight);

                img.layout(x, y, x+imgWidth, y+imgHeight);
                img.invalidate();
            }
        }
    }

    // 일정 시간 간격으로 쥐를 다시 그리도록 update()를 호출하는 쓰레드
    class MouseTask extends AsyncTask<Void, Void, Void>
    {
        @Override
        protected Void doInBackground(Void... params) {// 다른 쓰레드
            while(threadEndFlag){
                //다른 쓰레드에서는 UI를 접근할 수 없으므로
                publishProgress();	//자동으로 onProgressUpdate() 가 호출된다.
                try {
                    Thread.sleep(delay);
                } catch (InterruptedException e) {e.printStackTrace();}
            }
            return null;
        }
        @Override
        protected void onProgressUpdate(Void... values) {
            update();
            //scoreV.setText(String.format("SCORE : " + "%02d", score));
        }
    };//end MouseTask

}// end MainActivity
