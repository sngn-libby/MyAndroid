package edu.scsa.android.projectapp;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MemoMgr
{
    private static MemoMgr instance = null;
    ArrayList<Memo> MemoList;

    private MemoMgr()
    {
        MemoList = new ArrayList<>();
    }

    public static MemoMgr getInstance()
    {
        if(instance == null)
        {
            instance = new MemoMgr();
        }

        return instance;
    }

    public void addMemo(Memo m)
    {
       MemoList.add(m);
       Collections.sort(MemoList);
    }

    public void updateMemo(String title, Memo m)
    {
        int j = MemoList.size();

        for(int i=0;i<j;i++)
        {
            if(MemoList.get(i).getTitle().equals(title))
            {
                MemoList.get(i).setTitle(m.getTitle());
                MemoList.get(i).setDate(m.getDate());
                MemoList.get(i).setDone(m.isDone());
                Collections.sort(MemoList);
                return;
            }
        }
    }

    public void deleteMemo(String title)
    {
        int j = MemoList.size();

        for(int i=0;i<j;i++)
        {
            if(MemoList.get(i).getTitle().equals(title))
            {
                MemoList.remove(i);
                return;
            }
        }
    }

    public ArrayList<Memo> getAllMemo()
    {
        return MemoList;
    }

    public Memo getMemo(String title)
    {
        int j = MemoList.size();

        for(int i=0;i<j;i++)
        {
            if(MemoList.get(i).getTitle().equals(title))
            {
                return MemoList.get(i);
            }
        }

        return null;
    }
}
