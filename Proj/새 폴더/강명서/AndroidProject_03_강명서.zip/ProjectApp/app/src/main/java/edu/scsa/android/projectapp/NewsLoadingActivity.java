package edu.scsa.android.projectapp;

import android.os.AsyncTask;
import android.provider.DocumentsContract;
import android.util.Log;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;

public class NewsLoadingActivity
{
    private static NewsLoadingActivity instance = null;
    ArrayList<News> NewsList;

    DocumentBuilderFactory factory;
    DocumentBuilder builder;
    Document doc;

    final String maeil = "http://file.mk.co.kr/news/rss/rss_30100041.xml";
    final String korea = "http://rss.hankyung.com/new/news_main.xml";
    final String sisa = "https://www.sisain.co.kr/rss/allArticle.xml";
    final String nocut = "http://rss.nocutnews.co.kr/nocutnews.xml";

    private NewsLoadingActivity()
    {
        NewsList = new ArrayList<>();
    }


    public static NewsLoadingActivity getInstance()
    {
        if(instance == null)
        {
            instance = new NewsLoadingActivity();
        }

        return instance;
    }

    public ArrayList<News> getNews(int id)
    {
        NewsList.clear();

        //뉴스 로딩! AsyncTask
        try {
            new NetworkLoading().execute(id,null,null).get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return NewsList;
    }


    class NetworkLoading extends AsyncTask<Integer, String, Integer>
    {


        @Override
        protected Integer doInBackground(Integer... id)
        {
            try
            {
                factory = DocumentBuilderFactory.newInstance();
                builder = factory.newDocumentBuilder();

                switch(id[0])
                {
                    case 0: doc = builder.parse(maeil);
                        break;
                    case 1: doc = builder.parse(korea);
                        break;
                    case 2: doc = builder.parse(sisa);
                        break;
                    case 3: doc = builder.parse(nocut);
                        break;
                }

                NodeList TitleList = doc.getElementsByTagName("title");
                NodeList ContentList = doc.getElementsByTagName("description");
                NodeList LinkList = doc.getElementsByTagName("link");

                if(id[0]==1)
                {
                    for(int i=1;i<ContentList.getLength()-1;i++)
                    {
                        News tmp = new News();

                        tmp.setTitle(TitleList.item(i+1).getTextContent().trim());
                        tmp.setLink(LinkList.item(i+1).getTextContent().trim());
                        tmp.setContent(ContentList.item(i).getTextContent().trim());

                        NewsList.add(tmp);
                    }
                }
                else
                {
                    for(int i=2;i<TitleList.getLength();i++)
                    {
                        News tmp = new News();

                        tmp.setTitle(TitleList.item(i).getTextContent().trim());
                        tmp.setLink(LinkList.item(i).getTextContent().trim());
                        tmp.setContent(ContentList.item(i).getTextContent().trim());

                        NewsList.add(tmp);
                    }
                }
            }

            catch (ParserConfigurationException | IOException | SAXException e)
            {
                e.printStackTrace();
            }

            return 0;
        }

    }
}
