package edu.scsa.android.projectapp;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Memo implements Comparable<Memo>
{
    private String title;
    private String date;
    private boolean done;

    public Memo(String title, String date, boolean done)
    {
        this.title = title;
        this.date = date;
        this.done = done;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public String getDate()
    {
        return date;
    }

    public void setDate(String date)
    {
        this.date = date;
    }

    public boolean isDone()
    {
        return done;
    }

    public void setDone(boolean done)
    {
        this.done = done;
    }

    @Override
    public String toString()
    {
        return title;
    }

    @Override
    public int compareTo(Memo o)
    {
        SimpleDateFormat transFormat = new SimpleDateFormat("yyyy/MM/dd");

        try {
            return  transFormat.parse(this.date).compareTo(transFormat.parse(o.getDate()));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return 0;
    }
}
