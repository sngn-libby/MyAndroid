package edu.scsa.android.projectapp;

import android.provider.BaseColumns;

public final class DataBases
{
    public static final class CreateDB implements BaseColumns
    {
        public static final String TODO = "todo";
        public static final String DATE = "date";
        public static final String COMPLETE = "complete";
        public static final String _TABLENAME0 = "usertable";
        public static final String _CREATE0 = "create table if not exists "+_TABLENAME0+"("
                +_ID+" integer primary key autoincrement, "
                +TODO+" text not null , "
                +DATE+" integer not null , "
                +COMPLETE+" text not null );";
    }
}