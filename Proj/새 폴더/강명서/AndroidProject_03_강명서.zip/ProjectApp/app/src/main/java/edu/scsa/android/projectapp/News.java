package edu.scsa.android.projectapp;

import java.util.ArrayList;

public class News
{
    private String Title;
    private String Content;
    private String link;

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title)
    {
        this.Title = title;
    }

    public String getContent() {
        return Content;
    }

    public void setContent(String content)
    {
        this.Content = content;
    }

    public String getLink()
    {
        return link;
    }

    public void setLink(String link)
    {
        this.link = link;
    }

    @Override
    public String toString()
    {
        return link;
    }
}
