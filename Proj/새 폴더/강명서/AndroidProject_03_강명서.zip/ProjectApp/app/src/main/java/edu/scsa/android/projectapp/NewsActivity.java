package edu.scsa.android.projectapp;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class NewsActivity extends AppCompatActivity {

    ListView NewsListV;
    NewsLoadingActivity LoadMgr;
    NewsAdapter<News> NewsA;
    Button maeilB, koreaB, sisaB, nocutB;
    Intent web;

    private static int news_ID = 0;
    private static final int maeil_ID = 0;
    private static final int korea_ID = 1;
    private static final int sisa_ID = 2;
    private static final int nocut_ID = 3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);

        setTitle("Today News"); //타이틀 설정

        //뉴스로딩 객체 선언
        LoadMgr = NewsLoadingActivity.getInstance();

        //리스트뷰 설정
        NewsListV = findViewById(R.id.newsList); //리스트뷰 설정

        NewsA = new NewsAdapter<News> //어댑터 설정
                (R.layout.raw_news, LoadMgr.getNews(news_ID));

        NewsListV.setAdapter(NewsA); //리스트뷰에 어댑터 부착

        //버튼
        maeilB = findViewById(R.id.maeil);
        maeilB.setOnClickListener(new View.OnClickListener()
        {
          @Override
          public void onClick(View v)
          {
              news_ID = maeil_ID;
              NewsA = new NewsAdapter<News>
                      (R.layout.raw_news, LoadMgr.getNews(news_ID));
              NewsListV.setAdapter(NewsA);
          }
        });

        koreaB = findViewById(R.id.korea);
        koreaB.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                news_ID = korea_ID;
                NewsA = new NewsAdapter<News>
                        (R.layout.raw_news, LoadMgr.getNews(news_ID));
                NewsListV.setAdapter(NewsA);
            }
        });

        sisaB = findViewById(R.id.sisa);
        sisaB.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                news_ID = sisa_ID;
                NewsA = new NewsAdapter<News>
                        (R.layout.raw_news, LoadMgr.getNews(news_ID));
                NewsListV.setAdapter(NewsA);
            }
        });

        nocutB = findViewById(R.id.nocut);
        nocutB.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                news_ID = nocut_ID;
                NewsA = new NewsAdapter<News>
                        (R.layout.raw_news, LoadMgr.getNews(news_ID));
                NewsListV.setAdapter(NewsA);
            }
        });

        //뉴스 눌렀을 때
        NewsListV.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                String url = parent.getAdapter().getItem(position).toString();
                web = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(web);
            }
        });

    }

    private class ViewHolder
    {
        TextView nTitle;
        TextView nContent;
    }

    //뉴스 어댑터
    class NewsAdapter<n> extends BaseAdapter
    {
        private int layout; //레이아웃과 movList를 만든다.
        private ArrayList<News> newsList; //movList는 movie를 담는 arrayList
        News SelNews;

        public NewsAdapter(int rowLayout, ArrayList<News> newsList)
        {//생성자함수. rowLayout과 movList를 받아서 초기화
            this.layout = rowLayout;
            this.newsList = newsList;
            this.SelNews = new News();
        }

        @Override
        public int getCount()
        {
            return newsList.size();
        }

        @Override
        public Object getItem(int position)
        {
            return newsList.get(position);
        }

        @Override
        public long getItemId(int position)
        {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent)
        {
            ViewHolder viewHolder; //메모타이틀 하나를 가지고 있는 뷰홀더 생성.

            if(convertView==null) //1.convert view가 아직 없을 때만
            {
                convertView=View.inflate(NewsActivity.this, layout,null); //view 객체 생성.
                viewHolder = new ViewHolder(); //viewholder 객체 생성.
                viewHolder.nTitle = convertView.findViewById(R.id.titleV);
                viewHolder.nContent = convertView.findViewById(R.id.contentV);
                convertView.setTag(viewHolder);
            }
            else
            {
                viewHolder = (ViewHolder) convertView.getTag();
            }

            SelNews = newsList.get(position);
            viewHolder.nTitle.setText(SelNews.getTitle());
            viewHolder.nContent.setText(SelNews.getContent());

            return convertView;
        }
    }
}