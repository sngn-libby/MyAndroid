package edu.scsa.android.projectapp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.sql.SQLException;
import java.util.ArrayList;

public class ToDoListActivity extends AppCompatActivity
{
    Intent i;
    MemoMgr Manager;
    ListView MemoListV;
    MemoAdapter<Memo> MemoA;
    DBOpenHelper mDbOpenHelper;
    Cursor iCursor;

    public final int ADD_MODE = 1;
    public final int EDIT_MODE = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_to_do_list);

        setTitle("To Do List"); //타이틀 설정

        //메모 관리 객체 선언
        Manager = MemoMgr.getInstance();

        //초기데이터 불러오기
        mDbOpenHelper = new DBOpenHelper(this);
        try {
            mDbOpenHelper.open();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        mDbOpenHelper.create();
        iCursor = mDbOpenHelper.selectColumns();
        DBRead();

        //인텐트 선언
        i = new Intent(this, ToDoList_EditActivity.class);

        //리스트뷰-어댑터 관련
        MemoListV = findViewById(R.id.memoListV); //리스트뷰 설정
        MemoA = new MemoAdapter<Memo> //어댑터 설정
                (R.layout.raw_todo, Manager.getAllMemo());
        MemoListV.setAdapter(MemoA); //리스트뷰에 어댑터 부착

        //리스트뷰 context메뉴 등록
        registerForContextMenu(MemoListV);

        //리스트뷰 선택 시 완료 상태 변화 + 화면 갱신
        MemoListV.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                                       int position, long id)
            {
                String str = parent.getAdapter().getItem(position).toString();

                for(int i=0;i<Manager.MemoList.size();i++)
                {
                    if(str.equals(Manager.MemoList.get(i).getTitle()))
                    {
                        //자료 변화
                        Manager.MemoList.get(i).setDone(!(Manager.MemoList.get(i).isDone()));

                        //화면 갱신
                        MemoA = new MemoAdapter<Memo>
                                (R.layout.raw_todo, Manager.getAllMemo());
                        MemoListV.setAdapter(MemoA);

                        return;
                    }
                }
            }
        });
    }

    //메모어댑터 관련
    class MemoAdapter<M> extends BaseAdapter
    {
        private int layout;
        private ArrayList<Memo> MemoList;
        Memo SelMemo;

        public MemoAdapter(int rawLayout, ArrayList<Memo> MemoList)
        {//생성자함수. rowLayout과 movList를 받아서 초기화
            this.layout = rawLayout;
            this.MemoList = MemoList;
            SelMemo = new Memo("","",false);
        }

        @Override
        public int getCount()
        {
            return MemoList.size();
        }

        @Override
        public Object getItem(int position)
        {
            return MemoList.get(position);
        }

        @Override
        public long getItemId(int position)
        {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent)
        {
            ViewHolder viewHolder; //메모타이틀 하나를 가지고 있는 뷰홀더 생성.

            if(convertView==null) //1.convert view가 아직 없을 때만
            {
                convertView=View.inflate(ToDoListActivity.this, layout,null); //view 객체 생성.
                viewHolder = new ViewHolder(); //viewholder 객체 생성.
                viewHolder.todo = convertView.findViewById(R.id.todo);
                viewHolder.date = convertView.findViewById(R.id.date);
                viewHolder.done = convertView.findViewById(R.id.done);

                convertView.setTag(viewHolder);
            }
            else
            {
                viewHolder = (ViewHolder) convertView.getTag();
            }

            SelMemo = MemoList.get(position);
            viewHolder.todo.setText(SelMemo.getTitle());
            viewHolder.date.setText(SelMemo.getDate());

            if(SelMemo.isDone())
            {
                viewHolder.done.setImageResource(android.R.drawable.checkbox_on_background);
            }
            else
            {
                viewHolder.done.setImageResource(android.R.drawable.checkbox_off_background);
            }

            return convertView;
        }
    }

    //상단 메뉴 관련 - 추가
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        menu.add(0,Menu.FIRST,Menu.NONE,"추가")
                .setIcon(R.drawable.ic_add_white_30dp)
                .setShowAsActionFlags(MenuItem.SHOW_AS_ACTION_IF_ROOM);

        return super.onCreateOptionsMenu(menu);
    }

    private class ViewHolder
    {
        TextView todo;
        TextView date;
        ImageView done;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)  //메뉴 아이템 선택되었을 때
    {
        i.putExtra("REQUEST_CODE", "ADD_MODE");
        startActivityForResult(i, ADD_MODE);

        return super.onOptionsItemSelected(item);
    }

    //context 메뉴 관련 - 수정, 삭제
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo)
    {
        getMenuInflater().inflate(R.menu.memomenu, menu);

        super.onCreateContextMenu(menu, v, menuInfo);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item)
    {
        AdapterView.AdapterContextMenuInfo info =
                        (AdapterView.AdapterContextMenuInfo)item.getMenuInfo();

        int index= info.position; //AdapterView안에서 ContextMenu를 보여주는 항목의 위치

        switch(item.getItemId())
        {
            case R.id.modify:
                i.putExtra("REQUEST_CODE", "EDIT_MODE");
                i.putExtra("Edit_Memotitle", Manager.MemoList.get(index).toString());
                startActivityForResult(i, EDIT_MODE);
                return true;

            case R.id.delete:
                Manager.deleteMemo(Manager.MemoList.get(index).toString());
                //화면 갱신
                MemoA = new MemoAdapter<Memo>
                        (R.layout.raw_todo, Manager.getAllMemo());
                MemoListV.setAdapter(MemoA);
                return true;
        }
        return false;
    };

    @Override
    protected void onResume() {
        super.onResume();
        DBWrite();
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        DBWrite();
    }

    //edit Activity 결과(추가, 수정)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode==RESULT_CANCELED) return;

        String Todo = data.getStringExtra("todo");
        String Date = data.getStringExtra("date");
        Boolean Complete;
        if(data.getStringExtra("complete").equals("Y"))
        {
            Complete = true;
        }
        else
        {
            Complete = false;
        }

        Memo tmp = new Memo(Todo, Date, Complete);

        if(requestCode==ADD_MODE)
        {
            Manager.addMemo(tmp);
        }

        else if(requestCode==EDIT_MODE)
        {
            Manager.updateMemo(data.getStringExtra("Edit_Memotitle"), tmp);
        }

        //화면 갱신
        MemoA = new MemoAdapter<Memo>
                (R.layout.raw_todo, Manager.getAllMemo());
        MemoListV.setAdapter(MemoA);
    }


    //데이터 베이스 관련
    public void DBRead() {

        Log.e("INFO","DB READ...");
        Memo tmp;
        String dTodo = "";
        String dData = "";
        boolean dComplete = false;

        Manager.MemoList.clear();

        while (iCursor.moveToNext()) {
            dTodo = iCursor.getString(iCursor.getColumnIndex("todo"));
            dData = iCursor.getString(iCursor.getColumnIndex("date"));
            dComplete = (iCursor.getInt(iCursor.getColumnIndex
                    ("complete")) == 1);
            tmp = new Memo(dTodo, dData, dComplete);
            Manager.addMemo(tmp);
        }

    }

    public void DBWrite()
    {
        mDbOpenHelper.deleteAllColumns();
        Log.e("INFO","DB WRITE...");
        for(int i=0;i<Manager.MemoList.size();i++)
        {
            int j = 0;
            if(Manager.MemoList.get(i).isDone()) j = 1;

            mDbOpenHelper.insertColumn(Manager.MemoList.get(i).getTitle(),
                    Manager.MemoList.get(i).getDate(), j);
        }
    }
}


