package edu.scsa.android.projectapp;

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

public class ToDoList_EditActivity extends AppCompatActivity
{
    Button okB, cancelB;
    TextView Todo, Date, Complete;
    Intent recI, i;
    MemoMgr Manager;
    DatePicker datePicker;
    DatePickerDialog dateDialog;
    AlertDialog.Builder YNDial;
    AlertDialog YNDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editmemo);

        Manager = MemoMgr.getInstance();

        okB = findViewById(R.id.saveBut);
        cancelB = findViewById(R.id.cancelBut);
        Todo = findViewById(R.id.editTitle);
        Date = findViewById(R.id.editDate);
        Complete = findViewById(R.id.editComplete);

        recI = getIntent();
        i = new Intent();

        //수정이벤트라면 데이터를 입력해 두어야 한다.
        if(recI.getStringExtra("REQUEST_CODE").equals("EDIT_MODE"))
        {
            String str = recI.getStringExtra("Edit_Memotitle");
            int k;

            for(k=0;k<Manager.MemoList.size();k++)
            {
                if(str.equals(Manager.MemoList.get(k).getTitle())) break;
            }

            Todo.setText(str);
            Date.setText(Manager.MemoList.get(k).getDate());
            if(Manager.MemoList.get(k).isDone())
            {
                Complete.setText("Y");
            }
            else
            {
                Complete.setText("N");
            }
        }

        //날짜 선택창
        datePicker = (DatePicker) findViewById(R.id.datePicker);

        // DatePickerDialog
        dateDialog = new DatePickerDialog(this, R.style.DialogTheme);

        dateDialog.setOnDateSetListener(new DatePickerDialog.OnDateSetListener()
        {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth)
            {
                Date.setText(Integer.toString(year)+"/"+
                        Integer.toString(month+1)+"/"+Integer.toString(dayOfMonth));
            }
        });

        Date.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dateDialog.show();
            }
        });

        //Y/N 선택창
        final CharSequence[] oItems = {"Complete", "Not Yet"};
        final AlertDialog.Builder oDialog = new AlertDialog.Builder
                (this, R.style.DialogTheme);

        Complete.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

                oDialog.setTitle("Select State")
                        .setItems(oItems, new DialogInterface.OnClickListener()
                        {
                            @Override
                            public void onClick(DialogInterface dialog, int which)
                            {
                                if(oItems[which].equals("Complete"))
                                {
                                    Complete.setText("Y");
                                }
                                else
                                {
                                    Complete.setText("N");
                                }
                            }
                        })
                        .show();
            }
        });

    }

    //저장 이벤트
    public void saveEvent(View view)
    {
        String todo = Todo.getText().toString();
        String date = Date.getText().toString();
        String complete = Complete.getText().toString();


        if(todo.equals(""))
        {
            Snackbar.make(getWindow().getDecorView().getRootView(), "할 일을 입력해 주세요",
                    Snackbar.LENGTH_SHORT).setAction("Action",null).show();
            return;
        }

        if(date.equals(""))
        {
            Snackbar.make(getWindow().getDecorView().getRootView(), "기한을 입력해 주세요",
                    Snackbar.LENGTH_SHORT).setAction("Action",null).show();
            return;
        }

        if(complete.equals(""))
        {
            Snackbar.make(getWindow().getDecorView().getRootView(), "완료 여부를 입력해 주세요",
                    Snackbar.LENGTH_SHORT).setAction("Action",null).show();
            return;
        }

        //추가의 경우 : 같은 제목이 있으면 중복 경고 띄우`고 on Click이벤트 return
        if(recI.getStringExtra("REQUEST_CODE").equals("ADD_MODE"))
        {
            int i;
            int j = Manager.MemoList.size();

            for(i=0;i<j;i++)
            {
                if(Manager.MemoList.get(i).getTitle().equals(Todo.getText().toString()))
                {
                    Snackbar.make(getWindow().getDecorView().getRootView(), "중복된 할 일입니다",
                            Snackbar.LENGTH_SHORT).setAction("Action",null).show();
                    return;
                }
            }
        }

        //수정의 경우 : 본래의 제목 데이터 같이 전달해서 받아서 처리한다.
        if(recI.getStringExtra("REQUEST_CODE").equals("EDIT_MODE"))
        {
            i.putExtra("Edit_Memotitle", recI.getStringExtra("Edit_Memotitle"));
        }

        i.putExtra("todo",todo);
        i.putExtra("date",date);
        i.putExtra("complete",complete);

        setResult(RESULT_OK,i);
        finish();
    }

    public void cancelEvent(View view) {
        setResult(RESULT_CANCELED);
        finish();
    }
}
