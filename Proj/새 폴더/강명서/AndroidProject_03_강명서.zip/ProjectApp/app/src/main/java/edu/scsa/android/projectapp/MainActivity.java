package edu.scsa.android.projectapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity
{
    Button newsB, todoB, gameB;
    Intent i_n, i_t, i_g;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        newsB = findViewById(R.id.News);
        todoB = findViewById(R.id.ToDo);
        gameB = findViewById(R.id.Game);

        i_n = new Intent(this, NewsActivity.class);
        i_t = new Intent(this, ToDoListActivity.class);
        i_g = new Intent(this, GameActivity.class);


        newsB.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                startActivityForResult(i_n,0);
            }
        });

        todoB.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                startActivityForResult(i_t,0);
            }
        });

        gameB.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                startActivityForResult(i_g,0);
            }
        });

    }
}
