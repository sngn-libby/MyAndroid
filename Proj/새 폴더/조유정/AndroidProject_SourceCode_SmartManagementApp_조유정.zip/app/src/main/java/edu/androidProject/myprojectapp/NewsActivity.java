package edu.androidProject.myprojectapp;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.design.widget.TabLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;

public class NewsActivity extends AppCompatActivity {

    TabLayout tabLayout;
    ListView newsLv;
    private ArrayList<String> newsUriList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);

        newsLv = (ListView) findViewById(R.id.newsLv);
        tabLayout = (TabLayout) findViewById(R.id.tabLayout);

        new NewsParser().execute(0);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                int pos = tab.getPosition();
                new NewsParser().execute(pos);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });

        newsLv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(newsUriList.get(position)));
                startActivity(i);
            }
        });
    }


    class NewsParser extends AsyncTask<Integer, Void, Void>{
        ArrayList<News> newsList;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            newsList = new ArrayList<News>();
            newsUriList = new ArrayList<String>();
        }

        @Override
        protected Void doInBackground(Integer... args) {
            try {
                Document doc = Jsoup.connect("https://news.naver.com/main/main.nhn?sid1=" + (100 + args[0])).get();
                Elements mElementDataSize = doc.select("li[class=cluster_item]");
                int mElementSize = mElementDataSize.size();

                for(Element elem : mElementDataSize){
                    String imgUri = elem.select("div div[class=cluster_thumb_inner] a img").attr("src");
                    String newsTitle = elem.select("div[class=cluster_text] a").text();
                    String newsContent = elem.select("div div[class=cluster_text_lede]").text();
                    String uri = elem.select("div[class=cluster_text] a").attr("href");
                    newsList.add(new News(imgUri, newsTitle, newsContent));
                    newsUriList.add(uri);
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            NewsActivity.NewsAdapter<News> newsAdapter = new NewsActivity.NewsAdapter<News>(newsList);
            newsLv.setAdapter(newsAdapter);
        }
    }


    class NewsAdapter<M> extends BaseAdapter{
        private ArrayList<News> newsList;

        public NewsAdapter(ArrayList<News> newsList){
            this.newsList = newsList;
        }

        @Override
        public int getCount() {
            return newsList.size();
        }

        @Override
        public Object getItem(int position) {
            return newsList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder viewHolder;

            if(convertView == null) {
                convertView = View.inflate(NewsActivity.this, R.layout.news_layout, null);
                viewHolder = new ViewHolder();
                viewHolder.newsTitleTv = convertView.findViewById(R.id.newsTitleTv);
                viewHolder.newsContentTv = convertView.findViewById(R.id.newsContentTv);
                viewHolder.newsIv = convertView.findViewById(R.id.newsIv);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }

            News selNews = (News) getItem(position);
            viewHolder.newsTitleTv.setText(selNews.getTitle());
            viewHolder.newsContentTv.setText(selNews.getContent());
            if(selNews.getImgAddr().isEmpty()){
                viewHolder.newsIv.setImageResource(R.color.color_done);
            }
            else{
                Picasso.get().load(selNews.getImgAddr()).into(viewHolder.newsIv);
            }
            return convertView;
        }
    }

    class ViewHolder{
        TextView newsTitleTv;
        TextView newsContentTv;
        ImageView newsIv;
    }
}
