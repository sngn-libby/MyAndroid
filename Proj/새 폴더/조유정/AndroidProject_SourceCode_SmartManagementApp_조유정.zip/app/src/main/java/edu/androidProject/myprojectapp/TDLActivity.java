package edu.androidProject.myprojectapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class TDLActivity extends AppCompatActivity {

    public static final int ACTIVITY_CREATE=0;
    public static final int ACTIVITY_EDIT=1;
    public static final int ACTIVITY_ADDBOOK=2;

    private static final int INSERT_ID = android.view.Menu.FIRST;
    private static final int SORT_IMP_ID = android.view.Menu.FIRST + 1;
    private static final int SORT_TIME_ID = android.view.Menu.FIRST + 2;
    private static final int SHOW_DONE_ID = android.view.Menu.FIRST + 3;
    private static final int SHOWNOT_DONE_ID = android.view.Menu.FIRST + 4;
    private static final int DELETE_ID = Menu.FIRST + 1;
    private static final int DONE_ID = Menu.FIRST + 2;

    public static final int SORT_TIME = 0;
    public static final int SORT_IMP = 1;
    public static final int SHOW_DONE = 1;
    public static final int SHOWNOT_DONE = 0;

    public final static int[] IMPCOLORS
            = {R.color.color_imp0, R.color.color_imp1, R.color.color_imp2, R.color.color_imp3};

    TodoDbAdapter mDbHelper;
    ListView todoLv;
    MyCursorAdapter todos;
    int sortModeFlag;
    int showDoneFlag;
    SharedPreferences prefs;
    Menu optionsMenu;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tdl);

        prefs = getPreferences(MODE_PRIVATE);
        sortModeFlag = prefs.getInt("sortModeFlag", SORT_TIME);
        showDoneFlag = prefs.getInt("showDoneFlag", SHOW_DONE);

        todoLv = findViewById(R.id.todoLv);
        mDbHelper = new TodoDbAdapter(this);
        mDbHelper.open();

        fillData();
        registerForContextMenu(todoLv);

        todoLv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(TDLActivity.this, "CLICK", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(TDLActivity.this, TodoEdit.class);
                i.putExtra(TodoDbAdapter.KEY_ROWID, id);
                startActivityForResult(i, ACTIVITY_EDIT);
            }
        });
    }

    private void fillData() {
        Cursor todoCursor = mDbHelper.fetchAllTodo(sortModeFlag, showDoneFlag);
        startManagingCursor(todoCursor);

        String[] from = new String[]{TodoDbAdapter.KEY_TITLE};

        int[] to = new int[]{R.id.titleTv};

        todos = new MyCursorAdapter(this,
                R.layout.todo_layout, todoCursor, from, to);
        todoLv.setAdapter(todos);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(0, DELETE_ID, 0, R.string.todo_delete);
        menu.add(0, DONE_ID, 0, R.string.todo_done);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();

        switch(item.getItemId()) {
            case DELETE_ID:
                mDbHelper.deleteTodo(info.id);
                fillData();
                return true;
            case DONE_ID:
                mDbHelper.updateDone(info.id);
                showCntTodo();
                fillData();
                return true;
        }
        return super.onContextItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        return true;
    }


    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {

        menu.clear();
        menu.add(0, INSERT_ID, 0, R.string.todo_insert);

        if(sortModeFlag == SORT_IMP){
            menu.add(0, SORT_TIME_ID, 0, "시간순으로 정렬");
        } else{
            menu.add(0, SORT_IMP_ID, 0, "중요도순으로 정렬");
        }

        if(showDoneFlag == SHOW_DONE){
            menu.add(0, SHOWNOT_DONE_ID, 0, "한 일 표시 X");
        } else{
            menu.add(0, SHOW_DONE_ID, 0, "한 일 표시");
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case INSERT_ID:
                createTodo();
                return true;

            case SORT_IMP_ID:
                sortModeFlag = SORT_IMP;
                break;

            case SORT_TIME_ID:
                sortModeFlag = SORT_TIME;
                break;

            case SHOW_DONE_ID:
                showDoneFlag = SHOW_DONE;
                break;

            case SHOWNOT_DONE_ID:
                showDoneFlag = SHOWNOT_DONE;
                break;
        }

        fillData();
        return true;
    }

    private void createTodo() {
        Intent i = new Intent(this, TodoEdit.class);
        startActivityForResult(i, ACTIVITY_CREATE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        fillData();
    }

    public class MyCursorAdapter extends SimpleCursorAdapter {

        public MyCursorAdapter(Context context, int layout, Cursor cursor, String[] from, int[] to) {
            super(context, layout, cursor, from, to);
            showCntTodo();
        }

        public MyCursorAdapter(Context context, int layout, Cursor cursor, String[] from, int[] to, int flags) {
            super(context, layout, cursor, from, to, flags);
            showCntTodo();
        }

        @Override
        public void bindView(View view, Context context, Cursor cursor) {
            TextView impTv = (TextView) view.findViewById(R.id.impTv);
            TextView dateTv = (TextView) view.findViewById(R.id.dateTv);
            TextView timeTv = (TextView) view.findViewById(R.id.timeTv);
            TextView titleTv = (TextView) view.findViewById(R.id.titleTv);

            int colorId = IMPCOLORS[cursor.getInt(cursor.getColumnIndex(TodoDbAdapter.KEY_IMPORTANCE))];
            int year = cursor.getInt(cursor.getColumnIndex(TodoDbAdapter.KEY_YEAR));
            int month = cursor.getInt(cursor.getColumnIndex(TodoDbAdapter.KEY_MONTH));
            int day = cursor.getInt(cursor.getColumnIndex(TodoDbAdapter.KEY_DAY));
            int hour = cursor.getInt(cursor.getColumnIndex(TodoDbAdapter.KEY_HOUR));
            int minute = cursor.getInt(cursor.getColumnIndex(TodoDbAdapter.KEY_MINUTE));
            int done = cursor.getInt(cursor.getColumnIndex(TodoDbAdapter.KEY_DONE));

            if(done == 1){
                titleTv.setTextColor(getResources().getColor(R.color.color_done));
                dateTv.setTextColor(getResources().getColor(R.color.color_done));
                timeTv.setTextColor(getResources().getColor(R.color.color_done));
            } else {
                titleTv.setTextColor(getResources().getColor(R.color.color_font));
                dateTv.setTextColor(getResources().getColor(R.color.color_font));
                timeTv.setTextColor(getResources().getColor(R.color.color_font));
            }
            dateTv.setText(year +"-" + (month < 10 ? "0" : "") + month + "-"+ (day < 10 ? "0" : "") + day);
            timeTv.setText((hour < 10 ? "0" : "") + hour + ":" + (minute < 10 ? "0" : "") + minute);
            impTv.setBackgroundResource(colorId);
            super.bindView(view, context, cursor);
        }
    }

    public void showCntTodo(){
        TextView todoCntTv = (TextView) TDLActivity.this.findViewById(R.id.todoCntTv);
        int todoCnt = mDbHelper.countTodo();
        todoCntTv.setText("COUNT of TODO: " + todoCnt);
    }

    @Override
    protected void onStop() {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt("sortModeFlag", sortModeFlag);
        editor.putInt("showDoneFlag", showDoneFlag);
        editor.commit();
        super.onStop();
    }
}
