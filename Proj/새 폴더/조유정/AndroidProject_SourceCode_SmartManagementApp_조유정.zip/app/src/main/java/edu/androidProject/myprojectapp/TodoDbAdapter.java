package edu.androidProject.myprojectapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class TodoDbAdapter {

    public static final String KEY_TITLE = "title";
    public static final String KEY_YEAR = "year";
    public static final String KEY_MONTH = "month";
    public static final String KEY_DAY = "day";
    public static final String KEY_HOUR = "hour";
    public static final String KEY_MINUTE = "minute";
    public static final String KEY_CONTENT = "content";
    public static final String KEY_IMPORTANCE = "importance";
    public static final String KEY_ROWID = "_id";
    public static final String KEY_DONE = "done";

    private static final String[] allColKeys =
            {KEY_ROWID, KEY_TITLE, KEY_YEAR, KEY_MONTH, KEY_DAY, KEY_HOUR, KEY_MINUTE,
            KEY_CONTENT, KEY_IMPORTANCE, KEY_DONE};

    private static final String TAG = "TodoDbAdapter";
    private DatabaseHelper mDbHelper;
    private SQLiteDatabase mDb;

    /**
     * Database creation sql statement
     */
    private static final String DATABASE_CREATE =
            "create table todo (_id integer primary key autoincrement, "
                    + "title text not null, year integer not null, month integer not null, "
                    + "day integer not null, hour integer not null, minute integer not null, "
                    + "content text not null, importance integer not null, done integer not null);";

    private static final String DATABASE_NAME = "data";
    private static final String DATABASE_TABLE = "todo";
    private static final int DATABASE_VERSION = 11;

    private final Context mCtx;

    private static class DatabaseHelper extends SQLiteOpenHelper {

        DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {

            db.execSQL(DATABASE_CREATE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                    + newVersion + ", which will destroy all old data");
            db.execSQL("DROP TABLE IF EXISTS todo");
            onCreate(db);
        }
    }

    /**
     * Constructor - takes the context to allow the database to be
     * opened/created
     *
     * @param ctx the Context within which to work
     */
    public TodoDbAdapter(Context ctx) {
        this.mCtx = ctx;
    }

    /**
     * Open the notes database. If it cannot be opened, try to create a new
     * instance of the database. If it cannot be created, throw an exception to
     * signal the failure
     * 
     * @return this (self reference, allowing this to be chained in an
     *         initialization call)
     * @throws SQLException if the database could be neither opened or created
     */
    public TodoDbAdapter open() throws SQLException {
        mDbHelper = new DatabaseHelper(mCtx);
        mDb = mDbHelper.getWritableDatabase();
        return this;
    }
    
    public void close() {
        mDbHelper.close();
    }


    /*
     * Create a new note using the title and body provided. If the note is
     * successfully created return the new rowId for that note, otherwise return
     * a -1 to indicate failure.
     * 
     * @param
     *     public static final String KEY_TITLE = "title";
     *     public static final String KEY_DATE = "date";
     *     public static final String KEY_TIME = "time";
     *     public static final String KEY_CONTENT = "content";
     *     public static final boolean KEY_ALARM = "alarm";
     *     public static final int KEY_IMPORTANCE = "importance";
     *     public static final String KEY_ROWID = "_id";
     * @return rowId or -1 if failed
     */


    public long createTodo(String title, int year, int month, int day, int hour, int minute, String content, int importance, int done) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(KEY_TITLE, title);
        initialValues.put(KEY_YEAR, year);
        initialValues.put(KEY_MONTH, month);
        initialValues.put(KEY_DAY, day);
        initialValues.put(KEY_HOUR, hour);
        initialValues.put(KEY_MINUTE, minute);
        initialValues.put(KEY_CONTENT, content);
        initialValues.put(KEY_IMPORTANCE, importance);
        initialValues.put(KEY_DONE, done);

        return mDb.insert(DATABASE_TABLE, null, initialValues);
    }

    /**
     * Delete the note with the given rowId
     * 
     * @param rowId id of note to delete
     * @return true if deleted, false otherwise
     */
    public boolean deleteTodo(long rowId) {

        return mDb.delete(DATABASE_TABLE, KEY_ROWID + "=" + rowId, null) > 0;
    }

    /**
     * Return a Cursor over the list of all notes in the database
     * 
     * @return Cursor over all notes
     */
    public Cursor fetchAllTodo(int sortModeFlag, int showDoneFlag) {

        String orderQuery = KEY_DONE + " ASC";
        String selectionQuery = "";

        switch(sortModeFlag){
            case TDLActivity.SORT_TIME:
                orderQuery += ", " + KEY_YEAR + " ASC, " + KEY_MONTH + " ASC, " + KEY_DAY + " ASC, "
                        + KEY_HOUR + " ASC, " + KEY_MINUTE + " ASC";
                break;
            case TDLActivity.SORT_IMP:
                orderQuery += ", " + KEY_IMPORTANCE + " DESC";
                break;
        }

        switch(showDoneFlag){
            case TDLActivity.SHOWNOT_DONE:
                selectionQuery = KEY_DONE + "=0";
                break;
            case TDLActivity.SHOW_DONE:
                selectionQuery = "";
                break;
        }

        return mDb.query(DATABASE_TABLE, allColKeys, selectionQuery, null, null, null, orderQuery);
    }

    /**
     * Return a Cursor positioned at the note that matches the given rowId
     * 
     * @param rowId id of note to retrieve
     * @return Cursor positioned to matching todo, if found
     * @throws SQLException if note could not be found/retrieved
     */
    public Cursor fetchTodo(long rowId) throws SQLException {

        Cursor mCursor =

                mDb.query(true, DATABASE_TABLE, allColKeys, KEY_ROWID
                                + "=" + rowId, null, null, null, null, null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;

    }

    /*
     * Update the note using the details provided. The note to be updated is
     * specified using the rowId, and it is altered to use the title and body
     * values passed in
     * 
     * @param rowId id of note to update
     * @param title value to set note title to
     * @param body value to set note body to
     * @return true if the note was successfully updated, false otherwise
     */
    public boolean updateTodo(long rowId, String title, int year, int month, int day, int hour, int minute, String content, int importance, int done) {
        ContentValues args = new ContentValues();
        args.put(KEY_TITLE, title);
        args.put(KEY_YEAR, year);
        args.put(KEY_MONTH, month);
        args.put(KEY_DAY, day);
        args.put(KEY_HOUR, hour);
        args.put(KEY_MINUTE, minute);
        args.put(KEY_CONTENT, content);
        args.put(KEY_IMPORTANCE, importance);
        args.put(KEY_DONE, done);

        return mDb.update(DATABASE_TABLE, args, KEY_ROWID + "=" + rowId, null) > 0;
    }

    public boolean updateDone(long rowId){
        ContentValues args = new ContentValues();
        args.put(KEY_DONE, 1);

        return mDb.update(DATABASE_TABLE, args, KEY_ROWID + "=" + rowId, null) > 0;
    }

    public int countTodo(){
        Cursor mCursor = mDb.query(true, DATABASE_TABLE, new String[] { KEY_ROWID }, KEY_DONE
                + "=?", new String[] {"0"}, null, null, null, null);
        try {
            return (mCursor.moveToFirst()) ? mCursor.getCount():0;
        } finally {
            mCursor.close();
        }
    }
}
