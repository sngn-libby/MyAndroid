package edu.androidProject.myprojectapp;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TimePicker;

import java.util.Calendar;

public class TodoEdit extends AppCompatActivity {

    private EditText titleEt;
    private EditText contentEt;
    private EditText dateEt;
    private EditText timeEt;
    private SeekBar impSb;
    private Button okBut;

    private int year, month, day;
    private int hour, minute;

    private String title, author;

    private Long mRowId;
    private TodoDbAdapter mDbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mDbHelper = new TodoDbAdapter(this);
        mDbHelper.open();
        setContentView(R.layout.activity_todo_edit);

        titleEt = findViewById(R.id.titleEt);
        contentEt = findViewById(R.id.contentEt);
        dateEt = findViewById(R.id.dateEt);
        timeEt = findViewById(R.id.timeEt);
        impSb = findViewById(R.id.impSb);
        okBut = findViewById(R.id.okBut);

        mRowId = savedInstanceState != null ? savedInstanceState.getLong(TodoDbAdapter.KEY_ROWID) : null;

        if (mRowId == null) {
            Bundle extras = getIntent().getExtras();
            if(extras != null){
                mRowId = extras.getLong(TodoDbAdapter.KEY_ROWID, -1);
                if(mRowId < 0) mRowId = null;
                title = extras.getString("title");
                author = extras.getString("author");
            }
        }

        populateFields();

        dateEt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(
                        TodoEdit.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                dateEt.setText(year +"-" + pad(monthOfYear+1) + "-"+ pad(dayOfMonth));
                                TodoEdit.this.year  = year;
                                TodoEdit.this.month = monthOfYear + 1;
                                TodoEdit.this.day   = dayOfMonth;
                            }
                        },
                        Calendar.getInstance().get(Calendar.YEAR),
                        Calendar.getInstance().get(Calendar.MONTH),
                        Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
                ).show();
            }
        });

        timeEt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new TimePickerDialog(
                        TodoEdit.this,
                        new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                                timeEt.setText(pad(hourOfDay) +":" + pad(minute));
                                TodoEdit.this.hour = hourOfDay;
                                TodoEdit.this.minute = minute;
                            }
                        },
                        Calendar.getInstance().get(Calendar.HOUR_OF_DAY),
                        Calendar.getInstance().get(Calendar.MINUTE),
                        true
                ).show();
            }
        });

        okBut.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                saveState();
                setResult(RESULT_OK);
                finish();
            }
        });
    }

    private void populateFields() {
        if (mRowId != null) {
            Cursor todo = mDbHelper.fetchTodo(mRowId);
            //startManagingCursor(note);
            titleEt.setText(todo.getString(
                    todo.getColumnIndexOrThrow(TodoDbAdapter.KEY_TITLE)));
            contentEt.setText(todo.getString(
                    todo.getColumnIndexOrThrow(TodoDbAdapter.KEY_CONTENT)));
            impSb.setProgress(todo.getInt(todo.getColumnIndexOrThrow(TodoDbAdapter.KEY_IMPORTANCE)));

            year = todo.getInt(todo.getColumnIndexOrThrow(TodoDbAdapter.KEY_YEAR));
            month = todo.getInt(todo.getColumnIndexOrThrow(TodoDbAdapter.KEY_MONTH));
            day = todo.getInt(todo.getColumnIndexOrThrow(TodoDbAdapter.KEY_DAY));

            hour = todo.getInt(todo.getColumnIndexOrThrow(TodoDbAdapter.KEY_HOUR));
            minute = todo.getInt(todo.getColumnIndexOrThrow(TodoDbAdapter.KEY_MINUTE));
        } else{
            Calendar cal = Calendar.getInstance();
            year = cal.get(Calendar.YEAR);
            month = cal.get(Calendar.MONTH) + 1;
            day = cal.get(Calendar.DAY_OF_MONTH);
            hour = cal.get(Calendar.HOUR_OF_DAY);
            minute = cal.get(Calendar.MINUTE);
            if (title != null) {
                titleEt.setText("<<" + title + ">> 읽기");
                contentEt.setText("제목 : " + title + "\n저자 : " + author);
            }
        }
        dateEt.setText( year +"-" + month + "-" + day);
        timeEt.setText(hour +":" + minute);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putLong(TodoDbAdapter.KEY_ROWID, mRowId);
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        populateFields();
    }

    private void saveState() {
        String title = titleEt.getText().toString();
        String content = contentEt.getText().toString();
        int importance = impSb.getProgress();

        if (mRowId == null) {
            mDbHelper.createTodo(title, year, month, day, hour, minute, content, importance, 0);
        } else {
            mDbHelper.updateTodo(mRowId, title, year, month, day, hour, minute, content, importance, 0);
        }
    }

    private static String pad(int c) {
        if (c >= 10)
            return String.valueOf(c);
        else
            return "0" + String.valueOf(c);
    }
}
