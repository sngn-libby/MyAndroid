package edu.androidProject.myprojectapp;

import android.content.Intent;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.os.AsyncTask;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;


public class NfcReaderActivity extends AppCompatActivity {

    private static String clientID = "JUn3xte7WAWq_MGnPXRc";
    private static String clientSecret = "VRNZSHcyCt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);

        Intent recI = getIntent();
        String action = recI.getAction();
        if(action.equals(NfcAdapter.ACTION_NDEF_DISCOVERED)){
            processIntent(recI);
        }
    }

    private void processIntent(Intent i){
        Parcelable[] rawData = i.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);

        NdefMessage ndefM = (NdefMessage)rawData[0];
        NdefRecord[] recArr = ndefM.getRecords();
        NdefRecord textR = recArr[0];
        byte[] recT = textR.getType();

        String strT = new String(recT);

        byte[] bData;
        String sData;
        String[] extras;
        if(strT.equals("T")){
            bData = textR.getPayload();
            sData = new String(bData, 7, bData.length -7);
            new BookInfoGetter().execute(sData);
        }
    }

    class BookInfoGetter extends AsyncTask<String, Void, String[]>{

        @Override
        protected String[] doInBackground(String... args) {
            try {
                String title;
                String author;
                Document doc = Jsoup.connect("https://search.naver.com/search.naver?query=" + args[0]).get();
                Elements mElementDataSize = doc.select("li[class=sh_book_top]");
                if(mElementDataSize.size() > 0){
                    Element elem = mElementDataSize.get(0);
                    title = elem.select("dl dt a").text();
                    author = elem.select("dl dd span").get(0).select("span a").text();
                    return new String[] {title, author};
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String[] strings) {
            Intent i2 = new Intent(NfcReaderActivity.this, TodoEdit.class);
            i2.putExtra("title", strings[0]);
            i2.putExtra("author", strings[1]);
            startActivityForResult(i2, TDLActivity.ACTIVITY_ADDBOOK);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        finish();
    }
}
