package edu.androidProject.myprojectapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView menuLv;
    static final int MENU_TDL = 0;
    static final int MENU_BOOKINFO = 1;
    static final int MENU_GAME = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        menuLv = findViewById(R.id.menuLv);
        MenuAdapter<Menu> menuAdapter = new MenuAdapter<Menu>(R.layout.menu_layout, getAllInfo());
        menuLv.setAdapter(menuAdapter);

        // 메뉴 클릭 Event 구현
        menuLv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch(position){
                    case MENU_TDL:
                        startActivity(new Intent(MainActivity.this, TDLActivity.class));
                        break;
                    case MENU_BOOKINFO:
                        startActivity(new Intent(MainActivity.this, NewsActivity.class));
                        break;
                    case MENU_GAME:
                        startActivity(new Intent(MainActivity.this, GameActivity.class));
                        break;
                }
            }
        });
    }


    // Menu 구성
    class MenuAdapter<M> extends BaseAdapter {

        private int layout;
        private ArrayList<Menu> menuList;

        public MenuAdapter(int colLayout, ArrayList<Menu> menuList){
            this.layout = colLayout;
            this.menuList = menuList;
        }

        @Override
        public int getCount() {
            return menuList.size();
        }

        @Override
        public Object getItem(int position) {
            return menuList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView menuTv;

            if(convertView == null) {
                convertView = View.inflate(MainActivity.this, R.layout.menu_layout, null);
                menuTv = convertView.findViewById(R.id.menuTv);
                convertView.setTag(menuTv);
            } else {
                menuTv = (TextView) convertView.getTag();
            }

            Menu selMenu = (Menu) getItem(position);
            menuTv.setText(selMenu.getNameId());
            convertView.setBackgroundResource(selMenu.getColorId());

            return convertView;
        }
    };

    public ArrayList<Menu> getAllInfo(){
        ArrayList<Menu> tempList = new ArrayList<>();
        tempList.add(new Menu(R.string.TDL, R.color.color_first));
        tempList.add(new Menu(R.string.NEWS, R.color.color_second));
        tempList.add(new Menu(R.string.GAME, R.color.color_third));
        return tempList;
    }
}