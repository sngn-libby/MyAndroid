package edu.androidProject.myprojectapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class GameActivity extends AppCompatActivity {

    static final int SPRING = 0;
    static final int SUMMER = 1;
    static final int FALL = 2;
    static final int WINTER = 3;

    static final int[] IMG_RID = {
            R.drawable.spring1,
            R.drawable.spring2,
            R.drawable.spring3,
            R.drawable.summer1,
            R.drawable.summer2,
            R.drawable.summer3,
            R.drawable.fall1,
            R.drawable.fall2,
            R.drawable.fall3,
            R.drawable.winter1,
            R.drawable.winter2,
            R.drawable.winter3,
    };

    FrameLayout f;
    FrameLayout.LayoutParams params;
    int count=0;
    int delay=2000;
    static boolean threadEndFlag=true;
    MoveFoodTask moveFoodTask;
    TextView stageTv;
    TextView countTv;

    int myWidth;  // 내 폰의 너비
    int myHeight; // 내 폰의 높이
    int imgWidth=320;  //그림 크기
    int imgHeight=320;//그림 크기
    Random r=new Random();  // 이미지 위치를 랜덤하게 발생시킬 객체

    // 소리
    SoundPool pool;
    int wrongSound;
    int rightSound;
    int endSound;
    MediaPlayer mp;

    int x=200;        //시작위치
    int y=200;        //시작위치
    ImageView[] imgs; // 이미지들을 담아 놓을 배열

    int level=1;
    final int NUMS=12;
    final int GOAL=3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        f=(FrameLayout) findViewById(R.id.frame);
        params=new FrameLayout.LayoutParams(1, 1);

        stageTv = findViewById(R.id.stageTv);
        countTv = findViewById(R.id.countTv);
        stageTv.setText("STAGE : " + level);
        countTv.setText("COUNT : " + count);

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        myWidth=metrics.widthPixels;
        myHeight=metrics.heightPixels - 100;

        //사운드 셋팅
        pool = new SoundPool(1, AudioManager.STREAM_MUSIC, 0);
        wrongSound = pool.load(this, R.raw.wrongsound, 1);
        rightSound = pool.load(this, R.raw.rightsound, 1);
        endSound = pool.load(this, R.raw.endsound, 1);
        mp=MediaPlayer.create(this, R.raw.backbgm);
        mp.setLooping(true);

        init();
    }


    public void init(){

        count=0;
        threadEndFlag=true;
        delay=(int)(delay*(10-level)/10.);

        f.removeAllViews();

        //이미지 담을 배열 생성과 이미지 담기
        imgs = new ImageView[NUMS];
        for(int i=0; i<NUMS; i++){
            ImageView iv=new ImageView(this);
            iv.setTag(i/GOAL);
            iv.setImageResource(IMG_RID[i]);
            f.addView(iv, params);  // 화면에 표시
            imgs[i]=iv;     // 배열에 담기
            iv.setOnClickListener(h);  // 이벤트 등록
        }

        moveFoodTask = new MoveFoodTask();
        moveFoodTask.execute();
    }

    protected void onResume() {
        super.onResume();
        mp.start();
    };

    protected void onPause() {
        super.onPause();
        mp.stop();
    };

    protected void onDestroy() {
        super.onDestroy();
        mp.release();
        moveFoodTask.cancel(true);
        threadEndFlag = false;
    };


    View.OnClickListener  h=new View.OnClickListener() {
        public void onClick(View v) {


            ImageView iv=(ImageView)v;
            if((int)iv.getTag() == level - 1){
                iv.setVisibility(View.INVISIBLE);
                count++;
                pool.play(rightSound, 1, 1, 0, 0, 1);
                Toast.makeText(GameActivity.this, "정답!", Toast.LENGTH_SHORT).show();
                countTv.setText("COUNT : " + count);
            } else {
                pool.play(wrongSound, 1, 1, 0, 0, 1);
                Toast.makeText(GameActivity.this, "오답!", Toast.LENGTH_SHORT).show();
                return;
            }

            if(count==GOAL){
                threadEndFlag=false;
                stageTv.setText("STAGE : " + level);

                if(level++ == 4){
                    pool.play(endSound, 1, 1, 0, 0, 1);
                    AlertDialog.Builder dia=new AlertDialog.Builder(GameActivity.this);
                    dia.setMessage("모두 다 성공!");
                    dia.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            moveFoodTask.cancel(true);
                            finish();
                        }
                    });
                    dia.show();
                } else{
                    moveFoodTask.cancel(true);
                    AlertDialog.Builder dia=new AlertDialog.Builder(GameActivity.this);
                    dia.setMessage("LEVEL " + level + " 이동!");
                    dia.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            init();
                        }
                    });
                    dia.show();
                }
            }
        }
    };


    class MoveFoodTask extends AsyncTask<Void, Void, Void>{

        @Override
        protected Void doInBackground(Void... voids) {
            while(threadEndFlag){
                publishProgress();
                try {
                    Thread.sleep(delay);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            if(! threadEndFlag) return;

            for(ImageView img:imgs){
                x=r.nextInt(myWidth-imgWidth);
                y=r.nextInt(myHeight-imgHeight);

                img.layout(x, y, x+imgWidth, y+imgHeight);
                img.invalidate();
            }
        }
    };
}
