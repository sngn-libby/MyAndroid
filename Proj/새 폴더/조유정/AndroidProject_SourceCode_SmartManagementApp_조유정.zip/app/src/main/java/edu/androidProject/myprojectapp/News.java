package edu.androidProject.myprojectapp;

public class News {
    private String imgAddr;
    private String title;
    private String content;

    public News(String imgAddr, String title, String content) {
        this.imgAddr = imgAddr;
        this.title = title;
        this.content = content;
    }

    public String getImgAddr() {
        return imgAddr;
    }

    public void setImgAddr(String imgAddr) {
        this.imgAddr = imgAddr;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
