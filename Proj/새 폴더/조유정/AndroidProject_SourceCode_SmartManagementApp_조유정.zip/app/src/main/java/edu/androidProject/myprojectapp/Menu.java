package edu.androidProject.myprojectapp;

public class Menu {
    private int nameId;
    private int colorId;

    public Menu(int nameId, int colorId) {
        this.nameId = nameId;
        this.colorId = colorId;
    }

    public int getNameId() {
        return nameId;
    }

    public void setNameId(int nameId) {
        this.nameId = nameId;
    }

    public int getColorId() {
        return colorId;
    }

    public void setColorId(int colorId) {
        this.colorId = colorId;
    }
}

