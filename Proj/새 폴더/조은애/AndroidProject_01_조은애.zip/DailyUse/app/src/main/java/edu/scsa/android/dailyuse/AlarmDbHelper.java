package edu.scsa.android.dailyuse;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class AlarmDbHelper {
    private static final String DATABASE_NAME = "data";
    private static final int DATABASE_VERSION = 11;

    public static final String KEY_ROWID = "_id";
    public static final String KEY_NAME = "name";
    public static final String KEY_YEAR = "year";
    public static final String KEY_MONTH = "month";
    public static final String KEY_DATE = "date";
    public static final String KEY_HOUR = "hour";
    public static final String KEY_MIN = "minute";
    public static final String KEY_ACTIVE = "active";

    public static SQLiteDatabase mDB;
    private DatabaseHelper mDBHelper;
    private Context mCtx;

    private class DatabaseHelper extends SQLiteOpenHelper{


        public DatabaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
            super(context, name, factory, version);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(AlarmDb.CreateDB._CREATE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS "+AlarmDb.CreateDB._TABLENAME);
            onCreate(db);
        }
    }

    public AlarmDbHelper(Context context){
        this.mCtx = context;
    }

    public AlarmDbHelper open() throws SQLException{
        mDBHelper = new DatabaseHelper(mCtx, DATABASE_NAME, null, DATABASE_VERSION);
        mDB = mDBHelper.getWritableDatabase();
        return this;
    }

    public void create(){
        mDBHelper.onCreate(mDB);
    }

    public void close(){
        mDB.close();
    }

    public long insertColumn(String name, String year, String month, String date,
                             String hour, String minute, String active){
        ContentValues values = new ContentValues();
        values.put(AlarmDb.CreateDB.NAME, name);
        values.put(AlarmDb.CreateDB.YEAR, year);
        values.put(AlarmDb.CreateDB.MONTH, month);
        values.put(AlarmDb.CreateDB.DATE, date);
        values.put(AlarmDb.CreateDB.HOUR, hour);
        values.put(AlarmDb.CreateDB.MIN, minute);
        values.put(AlarmDb.CreateDB.ACTIVE, active);

        return mDB.insert(AlarmDb.CreateDB._TABLENAME, null, values);
    }

    public boolean updateColumn(int id, String name, String year, String month, String date,
                                String hour, String minute, String active){
        ContentValues values = new ContentValues();
        values.put(AlarmDb.CreateDB.NAME, name);
        values.put(AlarmDb.CreateDB.YEAR, year);
        values.put(AlarmDb.CreateDB.MONTH, month);
        values.put(AlarmDb.CreateDB.DATE, date);
        values.put(AlarmDb.CreateDB.HOUR, hour);
        values.put(AlarmDb.CreateDB.MIN, minute);
        values.put(AlarmDb.CreateDB.ACTIVE, active);
        return mDB.update(AlarmDb.CreateDB._TABLENAME, values, "_id=" + id, null) > 0;
    }

    public void deleteAllColumns() {
        mDB.delete(AlarmDb.CreateDB._TABLENAME, null, null);
    }

    public boolean deleteColumn(int id){
        return mDB.delete(AlarmDb.CreateDB._TABLENAME, "_id="+id, null) > 0;
    }

    public Cursor selectColumns(){
        return mDB.query(AlarmDb.CreateDB._TABLENAME, null, null, null, null, null, null);
    }

    public Cursor sortColumn(String sort){
        Cursor c = mDB.rawQuery( "SELECT * FROM alarmData ORDER BY " + sort + ";", null);
        return c;
    }

    public Cursor fetchAlarm(long rowId) throws SQLException {

        Cursor mCursor =
                mDB.query(true, AlarmDb.CreateDB._TABLENAME, new String[] {KEY_ROWID,
                                KEY_NAME, KEY_YEAR, KEY_MONTH, KEY_DATE, KEY_HOUR, KEY_MIN},
                        KEY_ROWID + "=" + rowId, null,
                        null, null, null, null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;

    }


    public Cursor getAll(){
        SQLiteDatabase mDb = mDBHelper.getReadableDatabase();
        Cursor c = mDB.rawQuery( "SELECT * FROM alarmData;", null);
        return c;
    }
}
