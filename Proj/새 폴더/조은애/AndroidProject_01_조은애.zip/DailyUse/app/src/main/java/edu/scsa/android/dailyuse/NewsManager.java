package edu.scsa.android.dailyuse;

import android.os.AsyncTask;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import java.io.IOException;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class NewsManager {

    private ArrayList<NewsData> newsA;
    DocumentBuilderFactory factory;
    DocumentBuilder builder;
    Document doc;

    public NewsManager() {
       newsA = new ArrayList<>();
    }

    public ArrayList<NewsData> updateNews(int idx){
       newsA.clear();
       switch (idx){
           case 1:
               new DataDownTask().execute("http://www.chosun.com/site/data/rss/rss.xml");
               break;
           case 2:
               new DataDownTask().execute("http://www.inews24.com/rss/news_it.xml");
               break;
           case 3:
               new DataDownTask().execute("http://rss.etnews.com/Section901.xml");
               break;
           case 4:
               new DataDownTask().execute("https://rss.joins.com/joins_news_list.xml");
               break;
       }
       return newsA;
    }

    public ArrayList<NewsData> getNews(){
        return newsA;
    }

    class DataDownTask extends AsyncTask<String, String, String> {
        String title;
        String desc;
        String link;

        @Override
        protected String doInBackground(String... url) {
            factory = DocumentBuilderFactory.newInstance();
            try {
                builder = factory.newDocumentBuilder();
            } catch (ParserConfigurationException e) {
                e.printStackTrace();
            }
            try {
                doc = builder.parse(url[0]);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (SAXException e) {
                e.printStackTrace();
            }

            Element elem = doc.getDocumentElement();
            NodeList itemList = elem.getElementsByTagName("item");
            if (itemList != null) {
                for (int i = 0; i < itemList.getLength(); i++) {
                    Element itemElem = (Element) itemList.item(i);
                    Element titleElem = (Element) itemElem.getElementsByTagName("title").item(0);
                    Element descElem = (Element) itemElem.getElementsByTagName("description").item(0);
                    Element linkElem = (Element) itemElem.getElementsByTagName("link").item(0);

                    title = titleElem.getFirstChild().getNodeValue();
                    desc = descElem.getFirstChild().getNodeValue();
                    link = linkElem.getFirstChild().getNodeValue();

                    newsA.add(new NewsData(title, desc, link));
                }
            }

            return null;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
        }
    }

}
