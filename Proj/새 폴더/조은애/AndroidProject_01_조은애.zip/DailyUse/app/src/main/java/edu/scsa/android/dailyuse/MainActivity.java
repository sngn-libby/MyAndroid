package edu.scsa.android.dailyuse;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TimePicker;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.SimpleTimeZone;

public class MainActivity extends AppCompatActivity {

    TextView timeTv;
    TextView dateTv;
    SimpleDateFormat timeFormat;
    SimpleDateFormat dateFormat;
    Button newsBtn;
    Button alarmBtn;
    Button gameBtn;

    NfcAdapter nfcAdapter;
    PendingIntent pIntent;
    IntentFilter[] filters;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        timeTv = findViewById(R.id.timeView);
        dateTv = findViewById(R.id.dateView);
        newsBtn = findViewById(R.id.newsButton);
        alarmBtn = findViewById(R.id.alarmButton);
        gameBtn = findViewById(R.id.gameButton);

        timeFormat = new SimpleDateFormat("HH : mm");
        dateFormat = new SimpleDateFormat("yyyy"+"년 "+"MM"+"월 "+"dd"+"일");

        newsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, NewsActivity.class);
                startActivity(i);
            }
        });

        alarmBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, AlarmActivity.class);
                startActivity(i);
            }
        });

        gameBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, GameActivity.class);
                startActivity(i);
            }
        });

        nfcAdapter = NfcAdapter.getDefaultAdapter(this);

        Intent i = new Intent(this, this.getClass());
        i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        pIntent = PendingIntent.getActivity(this, 0, i, 0);

        IntentFilter tagFilter = new IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED);
        filters = new IntentFilter[]{tagFilter};

        new Thread(r).start();
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
        nfcAdapter.enableForegroundDispatch(this, pIntent, filters, null);
    }

    Runnable r = new Runnable() {
        @Override
        public void run() {

            while(true){
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        dateTv.setText(dateFormat.format(new Date(System.currentTimeMillis())));
                        timeTv.setText(timeFormat.format(new Date(System.currentTimeMillis())));
                    }
                });
            }
        }
    };

    private void processIntent(Intent i){
        Parcelable[] rawData = i.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);
        NdefMessage ndefM = (NdefMessage) rawData[0];
        NdefRecord[] recArr = ndefM.getRecords(); // 레코드 몇개 들어있니?
        NdefRecord textR = recArr[0];
        byte[] recT = textR.getType();
        String strT = new String(recT);

        if(strT.equals("U")){
            Uri recUri = textR.toUri();
            Intent i2 = new Intent(Intent.ACTION_VIEW, recUri);
            startActivity(i2);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        processIntent(intent);
    }

    @Override
    protected void onPause() {
        super.onPause();
        nfcAdapter.disableForegroundDispatch(this);
    }
}

