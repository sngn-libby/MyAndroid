package edu.scsa.android.dailyuse;

import android.content.Context;
import android.database.Cursor;
import android.widget.TextView;

public class CustomTextView extends android.support.v7.widget.AppCompatTextView {

    Cursor myCursor;

    public Cursor getMyCursor() {
        return myCursor;
    }

    public void setMyCursor(Cursor myCursor) {
        this.myCursor = myCursor;
    }

    public CustomTextView(Context context) {
        super(context);
    }
}
