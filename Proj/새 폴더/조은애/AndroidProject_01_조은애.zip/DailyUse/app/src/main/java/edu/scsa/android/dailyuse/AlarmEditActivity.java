package edu.scsa.android.dailyuse;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class AlarmEditActivity extends AppCompatActivity {

    public static final int ADD_ALARM = 1;
    public static final int EDIT_ALARM = 2;

    private int mRowId;
    private AlarmDbHelper alarmDbHelper;

    EditText alarmName;
    TimePicker alarmTime;
    DatePicker alarmDate;
    Button saveBut, cancelBut;
    Intent i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm_edit);

        alarmName = findViewById(R.id.alarmName);
        alarmTime = findViewById(R.id.timePicker);
        alarmDate = findViewById(R.id.datePicker);
        saveBut = findViewById(R.id.saveBut);
        cancelBut = findViewById(R.id.cancelBut);

        alarmTime.setIs24HourView(true);

        alarmDbHelper = new AlarmDbHelper(this);

        i = getIntent();

        switch (i.getIntExtra("mode", 0)){
            case ADD_ALARM:
                break;
            case EDIT_ALARM:
                if(savedInstanceState == null){

                    mRowId = i.getIntExtra(AlarmDbHelper.KEY_ROWID, 0);
                    Log.d("INFO", "rowid : "+mRowId);

                    Cursor iCursor = alarmDbHelper.fetchAlarm(mRowId);
                    alarmName.setText(iCursor.getString(iCursor.getColumnIndexOrThrow(AlarmDbHelper.KEY_NAME)));
                    alarmTime.setHour(Integer.parseInt(iCursor.getString(iCursor.getColumnIndexOrThrow(AlarmDbHelper.KEY_HOUR))));
                    alarmTime.setMinute(Integer.parseInt(iCursor.getString(iCursor.getColumnIndexOrThrow(AlarmDbHelper.KEY_MIN))));

                    alarmDate.updateDate(Integer.parseInt(iCursor.getString(iCursor.getColumnIndexOrThrow(AlarmDbHelper.KEY_YEAR))),
                            Integer.parseInt(iCursor.getString(iCursor.getColumnIndexOrThrow(AlarmDbHelper.KEY_MONTH))),
                            Integer.parseInt(iCursor.getString(iCursor.getColumnIndexOrThrow(AlarmDbHelper.KEY_DATE))));

                }

                break;
        }

        saveBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                i.putExtra("name", alarmName.getText().toString());
                i.putExtra("year", String.valueOf(alarmDate.getYear()));
                i.putExtra("month", String.valueOf(alarmDate.getMonth()));
                i.putExtra("date", String.valueOf(alarmDate.getDayOfMonth()));
                i.putExtra("hour", String.valueOf(alarmTime.getHour()));
                i.putExtra("min", String.valueOf(alarmTime.getMinute()));
                setResult(RESULT_OK, i);
                finish();
            }
        });

        cancelBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_CANCELED);
                finish();
            }
        });
    }


}
