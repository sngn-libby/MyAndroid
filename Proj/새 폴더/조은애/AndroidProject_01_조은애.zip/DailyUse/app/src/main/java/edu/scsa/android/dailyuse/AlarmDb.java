package edu.scsa.android.dailyuse;

import android.provider.BaseColumns;

public final class AlarmDb {
    public static final class CreateDB implements BaseColumns{
        public static final String NAME = "name";
        public static final String YEAR = "year";
        public static final String MONTH = "month";
        public static final String DATE = "date";
        public static final String HOUR = "hour";
        public static final String MIN = "minute";
        public static final String ACTIVE = "active";

        public static final String _TABLENAME = "alarmData";
        public static final String _CREATE = "create table if not exists "+_TABLENAME+" ("
                +_ID+" integer primary key autoincrement, "
                +NAME+" text not null, "
                +YEAR+" text not null, "
                +MONTH+" text not null, "
                +DATE+" text not null, "
                +HOUR+" text not null, "
                +MIN+" text not null, "
                +ACTIVE+" text default 'on');";
    }
}
