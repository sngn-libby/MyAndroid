package edu.scsa.android.dailyuse;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.os.AsyncTask;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TabHost;
import android.widget.TabWidget;
import android.widget.TextView;
import android.widget.Toast;

import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;

public class NewsActivity extends AppCompatActivity {

    TabHost tabHost;
    SearchView searchEt;
    ListView chosunLv;
    ListView inewsLv;
    ListView etnewsLv;
    ListView joinsLv;
    NewsAdapter<NewsData> newsA;
    NewsManager nm;
    int selectedTab = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);

        chosunLv = findViewById(R.id.contLv1);
        inewsLv = findViewById(R.id.contLv2);
        etnewsLv = findViewById(R.id.contLv3);
        joinsLv = findViewById(R.id.contLv4);

        searchEt = findViewById(R.id.searchView);
        searchEt.setSubmitButtonEnabled(true);
        tabHost = findViewById(R.id.tabHost);
        tabHost.setup();

        TabHost.TabSpec tab1 = tabHost.newTabSpec("tab1");
        tab1.setContent(R.id.content1);
        tab1.setIndicator("조선일보");
        tabHost.addTab(tab1);

        TabHost.TabSpec tab2 = tabHost.newTabSpec("tab2");
        tab2.setContent(R.id.content2);
        tab2.setIndicator("아이뉴스");
        tabHost.addTab(tab2);

        TabHost.TabSpec tab3 = tabHost.newTabSpec("tab3");
        tab3.setContent(R.id.content3);
        tab3.setIndicator("전자신문");
        tabHost.addTab(tab3);

        TabHost.TabSpec tab4 = tabHost.newTabSpec("tab4");
        tab4.setContent(R.id.content4);
        tab4.setIndicator("중앙일보");
        tabHost.addTab(tab4);

        nm = new NewsManager();
        newsA = new NewsAdapter<>(R.layout.row_layout, nm.updateNews(1));
        chosunLv.setAdapter(newsA);

        chosunLv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Uri newsUri = Uri.parse(nm.getNews().get(position).getUrl());
                Intent i = new Intent(Intent.ACTION_VIEW, newsUri);
                startActivity(i);
            }
        });

        inewsLv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Uri newsUri = Uri.parse(nm.getNews().get(position).getUrl());
                Intent i = new Intent(Intent.ACTION_VIEW, newsUri);
                startActivity(i);
            }
        });

        etnewsLv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Uri newsUri = Uri.parse(nm.getNews().get(position).getUrl());
                Intent i = new Intent(Intent.ACTION_VIEW, newsUri);
                startActivity(i);
            }
        });

        joinsLv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Uri newsUri = Uri.parse(nm.getNews().get(position).getUrl());
                Intent i = new Intent(Intent.ACTION_VIEW, newsUri);
                startActivity(i);
            }
        });

        tabHost.setOnTabChangedListener(new TabHost.OnTabChangeListener() {
            @Override
            public void onTabChanged(String tabId) {
                switch (tabId){
                    case "tab1":
                        selectedTab = 1;
                        nm.updateNews(selectedTab);
                        chosunLv.setAdapter(newsA);
                        break;
                    case "tab2":
                        selectedTab = 2;
                        nm.updateNews(selectedTab);
                        inewsLv.setAdapter(newsA);
                        break;
                    case "tab3":
                        selectedTab = 3;
                        nm.updateNews(selectedTab);
                        etnewsLv.setAdapter(newsA);
                        break;
                    case "tab4":
                        selectedTab = 4;
                        nm.updateNews(selectedTab);
                        joinsLv.setAdapter(newsA);
                        break;
                }
            }
        });
    }

    public void search(View view) {
        String SearchWord = searchEt.getQuery().toString();
        Toast.makeText(this, SearchWord, Toast.LENGTH_SHORT).show();
    }

    class NewsAdapter<N> extends BaseAdapter{

        private int layout;
        private ArrayList<NewsData> newsList;
        private LayoutInflater layoutInf;

        public  NewsAdapter(int rowLayout, ArrayList<NewsData> newsList){
            this.layout = rowLayout;
            this.newsList = newsList;
            layoutInf = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public int getCount() {
            return newsList.size();
        }

        @Override
        public Object getItem(int position) {
            return newsList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            NewsData selNews = (NewsData) getItem(position);
            ViewHolder viewHolder;

            if(convertView == null){
                convertView = View.inflate(NewsActivity.this, layout, null);
                viewHolder = new ViewHolder();
                viewHolder.titleTv = convertView.findViewById(R.id.NewsV);
                convertView.setTag(viewHolder);
            }else{
                viewHolder = (ViewHolder) convertView.getTag();
            }

            viewHolder.titleTv.setText(selNews.getTitle());

            return convertView;
        }
    }

    class ViewHolder{
        TextView titleTv;
    }
}
