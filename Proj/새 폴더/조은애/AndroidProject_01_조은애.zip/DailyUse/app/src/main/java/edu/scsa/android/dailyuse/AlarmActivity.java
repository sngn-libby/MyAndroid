package edu.scsa.android.dailyuse;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatTextView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;


public class AlarmActivity extends AppCompatActivity {

    private static final int ADD = Menu.FIRST;

    public static final int ADD_ALARM = 1;
    public static final int EDIT_ALARM = 2;

    private AlarmDbHelper mAlarmDbHelper;
    MyCursorAdapter alarms;
    ListView alarmLv;
    View rowView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm);

        alarmLv = findViewById(R.id.alarmList);

        mAlarmDbHelper = new AlarmDbHelper(this);
        mAlarmDbHelper.open();
        mAlarmDbHelper.create();
        fillData();

        alarmLv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Toast.makeText(AlarmActivity.this, "눌림", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(AlarmActivity.this, AlarmEditActivity.class);
                i.putExtra(mAlarmDbHelper.KEY_ROWID, id);
                i.putExtra("mode", EDIT_ALARM);
                startActivityForResult(i, EDIT_ALARM);
            }
        });
    }

    private void fillData() {
        Cursor alarmCursor = mAlarmDbHelper.getAll();
        startManagingCursor(alarmCursor);

        String[] from = new String[]{};
        int[] to = new int[]{};

        alarms = new MyCursorAdapter(this, R.layout.alarm_layout, alarmCursor, from, to);
        alarmLv.setAdapter(alarms);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // TODO Auto-generated method stub
        menu.add(0, ADD, 0, R.string.addAlarm)
                .setIcon(android.R.drawable.ic_input_add)
                .setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case ADD:
                Intent i = new Intent(AlarmActivity.this, AlarmEditActivity.class);
                i.putExtra("mode", ADD_ALARM);
                startActivityForResult(i, ADD_ALARM);
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case ADD_ALARM :
                if (resultCode == RESULT_OK) {
                    mAlarmDbHelper.insertColumn(
                            data.getStringExtra("name"), data.getStringExtra("year"),
                            data.getStringExtra("month"), data.getStringExtra("date"),
                            data.getStringExtra("hour"), data.getStringExtra("min"),
                            "on");
                    alarmLv.setAdapter(alarms);
                    Toast.makeText(this, "저장 완료", Toast.LENGTH_SHORT).show();
                }
                break;
            case EDIT_ALARM:
                if(resultCode == RESULT_OK){
                    alarmLv.setAdapter(alarms);
                    Toast.makeText(this, "수정 완료", Toast.LENGTH_SHORT).show();
                }
        }
    }

    public class MyCursorAdapter extends SimpleCursorAdapter {

        AppCompatTextView timeTv;
        CustomTextView timeTv1;

        public MyCursorAdapter(Context context, int layout, Cursor cursor, String[] from, int[] to) {
            super(context, layout, cursor, from, to);
        }

        @Override
        public void bindView(View view, Context context, final Cursor cursor) {
            super.bindView(view, context, cursor);
            int a = cursor.getInt(cursor.getColumnIndex(AlarmDbHelper.KEY_ROWID));

            timeTv = view.findViewById(R.id.alarmTime);
            timeTv.setTag(cursor);

            TextView dateTv = view.findViewById(R.id.alarmDate);
            TextView descTv = view.findViewById(R.id.alarmDesc);
            Switch activeSw = view.findViewById(R.id.alarmActive);

            String name = cursor.getString(cursor.getColumnIndex("name"));
            String year = cursor.getString(cursor.getColumnIndex("year"));
            String month = cursor.getString(cursor.getColumnIndex("month"));
            String date = cursor.getString(cursor.getColumnIndex("date"));
            String hour = cursor.getString(cursor.getColumnIndex("hour"));
            String min = cursor.getString(cursor.getColumnIndex("minute"));
            String active = cursor.getString(cursor.getColumnIndex("active"));

            if(min.length()==1) min = "0"+min;
            month = String.valueOf(Integer.parseInt(month) + 1);

            timeTv.setText(hour + " : " + min);
            dateTv.setText(year +"년 " + month + "월 "+ date + "일");
            descTv.setText(name);
            if(active.equals("on")){
                activeSw.setChecked(true);
            }
            else{
                activeSw.setChecked(false);
            }

            timeTv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(v.getContext(), AlarmEditActivity.class);

                    Cursor cursor = (Cursor) v.getTag();
                    int b = cursor.getInt(cursor.getColumnIndex(AlarmDbHelper.KEY_ROWID));

                    i.putExtra(AlarmDbHelper.KEY_ROWID, b);
                    i.putExtra("mode", EDIT_ALARM);

                    startActivityForResult(i, EDIT_ALARM);
                }
            });
        }
    }
}
