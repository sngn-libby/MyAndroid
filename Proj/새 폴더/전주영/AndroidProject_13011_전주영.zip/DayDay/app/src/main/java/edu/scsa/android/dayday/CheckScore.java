package edu.scsa.android.dayday;

import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class CheckScore extends AppCompatActivity {

    private boolean mWriteMode = false;
    private boolean alreadyGet = false;
    private int[] rankScore = new int[3];
    private String[] rankName = new String[3];
    private int score;

    NfcAdapter nfcAdapter;
    TextView urScore;
    TextView etMsg;
    EditText name;

    PendingIntent pIntent;
    IntentFilter[] intentFilters;

    AlertDialog aa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_score);


        nfcAdapter = NfcAdapter.getDefaultAdapter(this);

        urScore = findViewById(R.id.yourScore);
        etMsg = findViewById(R.id.scoreInNFC);
        name = findViewById(R.id.registerName);

        pIntent = PendingIntent.getActivity(this, 0, new Intent(this,
                getClass()).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);

        IntentFilter tagFilter = new IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED);
        intentFilters = new IntentFilter[] {tagFilter};

        Intent i = getIntent();
        score = i.getIntExtra("score", 0);
        urScore.append(String.valueOf(score));


        findViewById(R.id.writeTag).setOnClickListener(
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mWriteMode = true;
                    if (tagBtnClicked()) {
                        aa = new AlertDialog.Builder(CheckScore.this)
                            .setTitle("Touch tag to write")
                            .setNegativeButton("취소",  new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int whichButton) {}
                            })
                            .setOnCancelListener( new DialogInterface.OnCancelListener() {
                                @Override
                                public void onCancel(
                                        DialogInterface dialog) {
                                    mWriteMode = false;

                                }
                            }).create();
                        aa.show();
                    }
                }
            });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (nfcAdapter == null) Log.i("NFC", "WHY???");
        else nfcAdapter.enableForegroundDispatch(this, pIntent, intentFilters, null);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        if (mWriteMode && NfcAdapter.ACTION_TAG_DISCOVERED.equals(intent.getAction())){
            Tag detectedTag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
            writeTag(makeNdefMessage(), detectedTag);
        } else if (!mWriteMode && !alreadyGet && NfcAdapter.ACTION_TAG_DISCOVERED.equals(intent.getAction())) {
            processIntent(intent);
            alreadyGet = true;
        }

        super.onNewIntent(intent);
    }

    @Override
    protected void onPause() {
        super.onPause();
        nfcAdapter.disableForegroundDispatch(this);
    }

    private void processIntent(Intent i) {
        Toast.makeText(this, "READ", Toast.LENGTH_SHORT).show();
        Parcelable[] rawData = i.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);
        NdefMessage ndefMessage = (NdefMessage) rawData[0];
        NdefRecord[] recArr = ndefMessage.getRecords();
        String ndefType = new String(recArr[0].getType());

        if (ndefType.equals("T")) {
            byte[] content =  recArr[0].getPayload();
            String str = new String(content, 4, content.length - 4);
            String[] tmp = str.split(";");

            etMsg.setText("1위 : " + tmp[0]);
            etMsg.append("\n2위 : " + tmp[1]);
            etMsg.append("\n3위 : " + tmp[2]);
            for (int n = 0; n < 3; n++) {
                String[] getScore = tmp[n].split(" ");
                rankScore[n] = Integer.parseInt(getScore[0]);
                Log.i("INFO", String.valueOf(rankScore[n]));
                rankName[n] = getScore[1];
            }
        } else {
            Log.i("INFO", "WRONG");
        }
    }

    private NdefMessage makeNdefMessage() {

        String str = null;
        for (int i = 0; i < 3; i++) {
            str += String.valueOf(rankScore[i]) + " " + rankName[i] + ";";
        }

        byte[] textBytes = str.getBytes();
        NdefRecord textRecord = new NdefRecord(NdefRecord.TNF_MIME_MEDIA,
                "T".getBytes(), new byte[] {}, textBytes);


        return new NdefMessage(new NdefRecord[] { textRecord });
    }

    boolean writeTag(NdefMessage message, Tag tag) {

        int size = message.toByteArray().length;

        try {
            Ndef ndef = Ndef.get(tag);

            ndef.connect();

            if (ndef.getMaxSize() < size) {
                return false;
            }

            ndef.writeNdefMessage(message);
            Toast.makeText(this,  "저장 성공", Toast.LENGTH_SHORT).show();

            aa.dismiss();

            return true;

        } catch (Exception e) {
            Toast.makeText(this,  "저장에 실패하였습니다.", Toast.LENGTH_SHORT).show();
        }
        return false;
    }

    public boolean tagBtnClicked() {
        String str = name.getText().toString();

        if (str.length() > 3) {
            Toast.makeText(this, "3글자 이하로 입력하세요.", Toast.LENGTH_SHORT).show();
            return false;
        }

        for (int i = 0; i < 3; i++) {
            if (rankScore[i] < score) {
                for (int j = 2; j > i; j--) {
                    rankScore[j] = rankScore[j-1];
                    rankName[j] = rankName[j-1];
                }
                rankScore[i] = score;
                rankName[i] = str;

                etMsg.setText("1위 : " + rankScore[0] + " " + rankName[0]);
                etMsg.append("\n2위 : " + rankScore[1] + " " + rankName[1]);
                etMsg.append("\n3위 : " + rankScore[2] + " " + rankName[2]);
                return true;
            }
        }

        Toast.makeText(this, "순위에 들지 못했어요ㅠ.ㅠ", Toast.LENGTH_SHORT).show();
        return false;
    }
}
