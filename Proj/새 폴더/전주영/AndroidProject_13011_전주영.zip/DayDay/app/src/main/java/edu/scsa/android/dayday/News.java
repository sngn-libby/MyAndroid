package edu.scsa.android.dayday;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.design.widget.TabLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.Xml;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;

import java.net.URL;
import java.util.ArrayList;

public class News extends AppCompatActivity {

    ListView lv;
    TabLayout tl;
    String url;
    String[] tag;
    String[] comps = new String[] {"조선일보", "중앙일보"};
    String[] pol = new String[] {"http://www.chosun.com/site/data/rss/politics.xml",
            "https://rss.joins.com/joins_politics_list.xml"};
    String[] eco = new String[] {"http://biz.chosun.com/site/data/rss/rss.xml",
            "https://rss.joins.com/joins_money_list.xml"};
    String[] soc = new String[] {"http://www.chosun.com/site/data/rss/national.xml",
            "https://rss.joins.com/joins_life_list.xml"};
    String[] spo = new String[] {"http://www.chosun.com/site/data/rss/sports.xml",
            "https://rss.joins.com/joins_sports_list.xml"};

    String[][] urls = new String[][] {
            pol, eco, soc, spo
    };

    myListViewAdapter<Item> myListViewAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);
        tl = findViewById(R.id.tabLayoutId);
        lv = findViewById(R.id.newsListView);

        tag = urls[0];
        new XMLParserTask().execute(tag);

        tl.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                tag = urls[tab.getPosition()];
                new XMLParserTask().execute(tag);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                tag = urls[tab.getPosition()];
                new XMLParserTask().execute(tag);
            }
        });

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView tmp = view.findViewById(R.id.newsLink);
                Log.i("ITEMLINK", tmp.getText().toString());
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(tmp.getText().toString()));
                startActivity(i);
            }
        });
    }


    class XMLParserTask extends AsyncTask<String[], String, ArrayList<Item>> {

        ArrayList<Item> list = new ArrayList<Item>();
        XmlPullParser parser = Xml.newPullParser();

        @Override
        protected ArrayList<Item> doInBackground(String[]... strings) {
            try {
                for (int x = 0; x < 2; x++) {
                    String comName = "< " + comps[x] + " >";
                    int itemCount = 0;
                    parser.setInput(new URL(strings[0][x])
                            .openConnection().getInputStream(), null);
                    int eventType = parser.getEventType();
                    Item i = null;
                    while (eventType != XmlPullParser.END_DOCUMENT) {
                        String name = null;
                        switch (eventType) {
                            case XmlPullParser.START_DOCUMENT:
                                break;
                            case XmlPullParser.START_TAG:
                                name = parser.getName();
                                if (name.equalsIgnoreCase("item")) {
                                    i = new Item();
                                    itemCount++;
                                } else if (i != null) {
                                    if (name.equalsIgnoreCase("title")) {
                                        if (itemCount == 0) break;
                                        i.setTitle(parser.nextText());
                                        i.setCompany(comName);
                                    } else if (name.equalsIgnoreCase("link")) {
                                        String link = parser.nextText();
                                        Log.i("LINK", link);
                                        i.setLink(link);
                                    } else if (name.equalsIgnoreCase("date") && x == 0) {
                                        String[] strs = parser.nextText().split("T");
                                        i.setDate(strs[0]);
                                    } else if (name.equalsIgnoreCase("pubDate") && x == 1) {
                                        String[] strs = parser.nextText().split("T");
                                        i.setDate(strs[0]);
                                    } else if (name.equalsIgnoreCase("author")) {
                                        String[] strs = parser.nextText().split("[(]");
                                        i.setAuthor(strs[0]);
                                    }
                                }
                                break;
                            case XmlPullParser.END_TAG:
                                name = parser.getName();
                                if (name.equalsIgnoreCase("item") && i != null) {
                                    list.add(i);
                                }
                                break;
                        }
                        eventType = parser.next();
                        if (itemCount == 6) break;
                    }
                }
            } catch(Exception e){
                e.printStackTrace();
            }

            return list;
        }

        protected void onPostExecute(ArrayList<Item> result) {
            myListViewAdapter = new myListViewAdapter(R.layout.news_row_layout, result);
            lv.setAdapter(myListViewAdapter);
        }
    }

    class myListViewAdapter<I> extends BaseAdapter {
        private int layout;
        private ArrayList<Item> tmpItemList;

        public myListViewAdapter(int layout, ArrayList<Item> tmpItemList) {
            this.layout = layout;
            this.tmpItemList = tmpItemList;
        }

        @Override
        public int getCount() {
            return tmpItemList.size();
        }

        @Override
        public Object getItem(int position) {
            return tmpItemList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Item i = (Item)getItem(position);
            ViewHolder vh;
            if (convertView == null) {
                convertView = View.inflate(News.this, layout, null);
                vh = new ViewHolder();
                vh.tv_company = convertView.findViewById(R.id.newsCompany);
                vh.tv_title = convertView.findViewById(R.id.newsTitle);
                vh.tv_author = convertView.findViewById(R.id.newsAuthor);
                vh.tv_date = convertView.findViewById(R.id.newsDate);
                vh.tv_link = convertView.findViewById(R.id.newsLink);
                convertView.setTag(vh);
            } else {
                vh = (ViewHolder) convertView.getTag();
            }

            vh.tv_company.setText(i.getCompany());
            vh.tv_title.setText(i.getTitle());
            vh.tv_author.setText(i.getAuthor());
            vh.tv_date.setText(i.getDate());
            vh.tv_link.setText(i.getLink());

            return convertView;
        }
    }

    class ViewHolder {
        TextView tv_company;
        TextView tv_title;
        TextView tv_author;
        TextView tv_date;
        TextView tv_link;
    }
}
