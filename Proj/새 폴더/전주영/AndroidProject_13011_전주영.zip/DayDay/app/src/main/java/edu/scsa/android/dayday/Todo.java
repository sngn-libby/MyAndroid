package edu.scsa.android.dayday;

public class Todo implements Comparable{
    private int id;
    private String content;
    private int status;

    public Todo() {
    }

    public Todo(String note, int status) {
        this.content = note;
        this.status = status;
    }

    public Todo(int id, String note, int status) {
        this.id = id;
        this.content = note;
        this.status = status;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    @Override
    public int compareTo(Object o) {
        return this.content.compareTo(((Todo)o).getContent());
    }
}
