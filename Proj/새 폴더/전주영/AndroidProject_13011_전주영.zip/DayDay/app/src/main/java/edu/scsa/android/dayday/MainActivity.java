package edu.scsa.android.dayday;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    TextView date, time;
    ListView mainTdlLv;
    String dateStr, timeStr;
    TdlDBManager tdlDBManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        date = findViewById(R.id.dateToday);
        time = findViewById(R.id.timeNow);
        mainTdlLv = findViewById(R.id.tdlMainList);

        tdlDBManager = new TdlDBManager(this);

        dateStr = new SimpleDateFormat("yyyy / MM / dd").format(new Date());
        timeStr = new SimpleDateFormat("HH : mm : ss")
                .format(new Date(System.currentTimeMillis()));

        date.setText(dateStr);
        time.setText(timeStr);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Thread t = new Thread () {
            @Override
            public void run() {
                try {
                    while (!isInterrupted()) {
                        sleep(1000);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                timeStr = new SimpleDateFormat("HH : mm : ss")
                                        .format(new Date(System.currentTimeMillis()));
                                time.setText(timeStr);
                            }
                        });
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };

        t.start();

        fillListView();
        mainTdlLv.setClickable(false);
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    public void fillListView() {
        ArrayList<Todo> todoArr= tdlDBManager.fetchAllToDosByDate(dateStr);
        int size = todoArr.size();
        int cnt = 0;
        String[] contentArr = new String[size];

        if (size > 0) Collections.sort(todoArr);
        for (int i = 0; i < size; i++) {
            Todo tmp = todoArr.get(i);
            if (tmp.getStatus() == TodoList.STATUS_DONE) continue;
            contentArr[cnt++] = tmp.getContent();
        }
        mainTdlLv.setAdapter(new ArrayAdapter<String>
                (this, android.R.layout.simple_list_item_1, contentArr));
    }


    public void todoli(View view) {
        Intent i = new Intent(this, TodoList.class);
        startActivity(i);
    }

    public void game(View view) {
        Intent i = new Intent(this, Game.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
        startActivity(i);
    }

    public void news(View view) {
        Intent i = new Intent(this, News.class);
        startActivity(i);
    }
}
