package edu.scsa.android.dayday;

public class Todo_Date implements Comparable{
    private int id;
    private String date;

    public Todo_Date() {
    }

    public Todo_Date(String date) {
        this.date = date;
    }

    public Todo_Date(int id, String date) {
        this.id = id;
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public int compareTo(Object o) {
        return this.date.compareTo(((Todo_Date)o).getDate());
    }
}
