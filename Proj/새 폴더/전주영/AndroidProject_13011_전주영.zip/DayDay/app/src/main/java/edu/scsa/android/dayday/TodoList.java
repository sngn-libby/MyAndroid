package edu.scsa.android.dayday;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Build;
import android.support.annotation.ColorInt;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseExpandableListAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;

public class TodoList extends AppCompatActivity {

    private static final int ADD_ID = Menu.FIRST;
    private static final int SEARCH_ID = Menu.FIRST + 1;
    private static final int EDIT_ID = Menu.FIRST + 2;

    public static final int STATUS_TODO = 0;
    public static final int STATUS_DONE = 1;

    ExpandableListView tdlList;
    String strDate;
    TdlDBManager tdlDBManager;
    ExpandableListAdapter expandableListAdapter;
    DatePicker dP;
    Todo editTodo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todo_list);
        tdlDBManager = new TdlDBManager(this);

        tdlList = findViewById(R.id.tdlListByDate);

        tdlList.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {

            @Override
            public boolean onChildClick(ExpandableListView parent, View v,
                                        int groupPosition, int childPosition, long id) {
                TextView tvtmp = v.findViewById(R.id.rowTdlTitle);
                Todo tmpTd = (Todo)tvtmp.getTag();

                if (tmpTd.getStatus() == STATUS_TODO) {
                    tmpTd.setStatus(STATUS_DONE);
                    tdlDBManager.updateToDo(tmpTd);
                    tvtmp.setTag(tmpTd);
                    tvtmp.setPaintFlags(tvtmp.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                    v.findViewById(R.id.editBtn).setVisibility(View.INVISIBLE);
                } else {
                    tmpTd.setStatus(STATUS_TODO);
                    tdlDBManager.updateToDo(tmpTd);
                    tvtmp.setTag(tmpTd);
                    tvtmp.setPaintFlags(tvtmp.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
                    v.findViewById(R.id.editBtn).setVisibility(View.VISIBLE);
                }

                return true;
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) getAllTdl();
    }

    private void getAllTdl() {
        ArrayList<Todo_Date> groupList = tdlDBManager.fetchAllDates();
        ArrayList<ArrayList<Todo>> childList = new ArrayList<>();
        if (groupList.size() > 0) Collections.sort(groupList);
        for (int i = 0; i < groupList.size(); i++) {
            Todo_Date tmp = groupList.get(i);
            ArrayList<Todo> contentList = tdlDBManager.fetchAllToDosByDate(tmp.getDate());
            Collections.sort(contentList);
            childList.add(i, contentList);
        }

        if (childList.size() != 0) {
            expandableListAdapter = new ExpandableListAdapter(this, groupList, childList);
            tdlList.setAdapter(expandableListAdapter);
            tdlList.setVisibility(View.VISIBLE);
            for (int i = 0; i < groupList.size(); i++) {
                tdlList.expandGroup(i);
            }
        } else {
            tdlList.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        menu.add(0, ADD_ID, 0, R.string.menu_add)
                .setIcon(android.R.drawable.ic_menu_add)
                .setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        menu.add(0, SEARCH_ID, 0, R.string.menu_search)
                .setIcon(android.R.drawable.ic_menu_search)
                .setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        showDialog(item.getItemId());

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case ADD_ID :
                final View tmpV= LayoutInflater.from(TodoList.this).inflate(R.layout.dialog_tdl, null);
                dP = tmpV.findViewById(R.id.datepicker);

                dP.init(dP.getYear(), dP.getMonth(), dP.getDayOfMonth(), new DatePicker.OnDateChangedListener() {

                    @Override
                    public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                       strDate = new String().format("%d / %d / %d", year, monthOfYear + 1, dayOfMonth);
                    }
                });
                ((EditText)tmpV.findViewById(R.id.editTextTdl)).setText("");
                 AlertDialog a = new AlertDialog.Builder(TodoList.this)
                        .setTitle("할일 추가하기")
                        .setView(tmpV)
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {}
                        })
                        .setPositiveButton("저장", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                String dateSelected = String.format("%d / %d / %d", dP.getYear(), dP.getMonth() + 1, dP.getDayOfMonth());
                                String tdlContent = ((TextView)tmpV.findViewById(R.id.editTextTdl)).getText().toString();
                                long date_id = tdlDBManager.createDate(new Todo_Date(dateSelected));
                                long todo_id = tdlDBManager.createToDo(new Todo(tdlContent, STATUS_TODO), date_id);
                            }
                        })
                        .create();
                return a;
            case SEARCH_ID:
                break;

            case EDIT_ID:
                final View tmpV2 = LayoutInflater.from(TodoList.this).inflate(R.layout.dialog_tdl, null);
                dP = tmpV2.findViewById(R.id.datepicker);
                dP.setEnabled(false);

                EditText tmpEt = tmpV2.findViewById(R.id.editTextTdl);
                tmpEt.setText(editTodo.getContent());

                AlertDialog aa = new AlertDialog.Builder(TodoList.this)
                        .setTitle("수정하기")
                        .setView(tmpV2)
                        .setNegativeButton("취소", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {}
                        })
                        .setPositiveButton("저장", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                String tdlContent = ((TextView)tmpV2.findViewById(R.id.editTextTdl)).getText().toString();
                                editTodo.setContent(tdlContent);
                                tdlDBManager.updateToDo(editTodo);
                            }
                        })
                        .create();
                return aa;
        }
        return null;
    }


    class ExpandableListAdapter extends BaseExpandableListAdapter {
        private ArrayList<Todo_Date> groupList = null;
        private ArrayList<ArrayList<Todo>> childList = null;
        private LayoutInflater inflater = null;

        public ExpandableListAdapter(Context c, ArrayList<Todo_Date> groupList,
                                     ArrayList<ArrayList<Todo>> childList){
            super();
            this.inflater = (LayoutInflater)c.getSystemService(LAYOUT_INFLATER_SERVICE);
            this.groupList = groupList;
            this.childList = childList;
        }

        @Override
        public int getGroupCount() {
            return groupList.size();
        }

        @Override
        public int getChildrenCount(int groupPosition) {
            return childList.get(groupPosition).size();
        }

        @Override
        public Object getGroup(int groupPosition) {
            return groupList.get(groupPosition);
        }

        @Override
        public Object getChild(int groupPosition, int childPosition) {
            return childList.get(groupPosition).get(childPosition);
        }

        @Override
        public long getGroupId(int groupPosition) {
            return groupPosition;
        }

        @Override
        public long getChildId(int groupPosition, int childPosition) {
            return childPosition;
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }

        @Override
        public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
            View v = convertView;
            ViewHolder viewHolder;

            if(v == null){
                viewHolder = new ViewHolder();
                v = inflater.inflate(R.layout.group_layout, parent, false);
                viewHolder.tv_groupName = (TextView) v.findViewById(R.id.groupName);
                v.setTag(viewHolder);
            }else{
                viewHolder = (ViewHolder)v.getTag();
            }
            viewHolder.tv_groupName.setText(((Todo_Date)getGroup(groupPosition)).getDate());
            v.setBackgroundColor(getResources().getColor(R.color.dateBack));
            return v;
        }

        @Override
        public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
            View v = convertView;
            ViewHolder viewHolder;
            Todo td = (Todo)getChild(groupPosition, childPosition);

            if(v == null){
                viewHolder = new ViewHolder();
                v = inflater.inflate(R.layout.tdl_row_layout, null);
                viewHolder.tv_childName = v.findViewById(R.id.rowTdlTitle);
                viewHolder.iv_edit = v.findViewById(R.id.editBtn);
                viewHolder.tv_childName.setTag(td);
                v.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder)v.getTag();
            }

            viewHolder.tv_childName.setText(td.getContent());
            if (td.getStatus() == STATUS_DONE) {
                viewHolder.tv_childName
                        .setPaintFlags(viewHolder.tv_childName.getPaintFlags()| Paint.STRIKE_THRU_TEXT_FLAG);
                viewHolder.iv_edit.setVisibility(View.INVISIBLE);
            }

            return v;
        }

        @Override
        public boolean isChildSelectable(int groupPosition, int childPosition) {
            return true;
        }
    }

    class ViewHolder {
        public TextView tv_groupName;
        public TextView tv_childName;
        public ImageView iv_edit;
    }


    public void editTodoEvent(View view) {

        TextView contentTv = ((View)view.getParent()).findViewById(R.id.rowTdlTitle);
        editTodo = (Todo)contentTv.getTag();

        showDialog(EDIT_ID);
    }

    public void deleteTodoEvent(View view) {
        TextView contentTv = ((View)view.getParent()).findViewById(R.id.rowTdlTitle);
        int id = ((Todo)contentTv.getTag()).getId();
        Todo_Date tmpDate = tdlDBManager.fetchDate(id);

        tdlDBManager.deleteToDo(id);
        if (!tdlDBManager.hasTodo(tmpDate)) {
            tdlDBManager.deleteDate(tmpDate);
        }
        getAllTdl();
    }
}
