package edu.scsa.android.dayday;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class TdlDBManager extends SQLiteOpenHelper{

    private static final int DATABASE_VERSION = 1;

    private static final String DATABASE_NAME = "todolist";

    private static final String TABLE_TODO = "todos";
    private static final String TABLE_DATE = "dates";
    private static final String TABLE_TODO_DATE = "todo_dates";

    private static final String KEY_ID = "_id";

    private static final String KEY_CONTENT = "content";
    private static final String KEY_STATUS = "status";

    private static final String KEY_DATE_NAME = "date_name";

    private static final String KEY_TODO_ID = "todo_id";
    private static final String KEY_DATE_ID = "date_id";

    private static final String CREATE_TABLE_TODO =
            "CREATE TABLE " + TABLE_TODO + "("
            + KEY_ID + " INTEGER PRIMARY KEY autoincrement,"
            + KEY_CONTENT + " TEXT NOT NULL,"
            + KEY_STATUS + " INTEGER"
            + ");";

    private static final String CREATE_TABLE_DATE =
            "CREATE TABLE " + TABLE_DATE + "("
            + KEY_ID + " INTEGER PRIMARY KEY autoincrement,"
            + KEY_DATE_NAME + " TEXT NOT NULL"
            + ");";

    private static final String CREATE_TABLE_TODO_DATE =
            "CREATE TABLE " + TABLE_TODO_DATE + "("
            + KEY_ID + " INTEGER PRIMARY KEY autoincrement,"
            + KEY_TODO_ID + " INTEGER,"
            + KEY_DATE_ID + " INTEGER"
            + ");";

    public TdlDBManager(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_DATE);
        db.execSQL(CREATE_TABLE_TODO);
        db.execSQL(CREATE_TABLE_TODO_DATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TODO);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DATE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TODO_DATE);

        onCreate(db);
    }

    public long createToDo(Todo todo, long date_id) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_CONTENT, todo.getContent());
        values.put(KEY_STATUS, todo.getStatus());

        long todo_id = db.insert(TABLE_TODO, null, values);

        createTodoDate(todo_id, date_id);

        return todo_id;
    }

    public Todo fetchTodo(long todo_id) {
        SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT  * FROM " + TABLE_TODO + " WHERE "
                + KEY_ID + " = " + todo_id;

        Cursor c = db.rawQuery(selectQuery, null);

        if (c != null) {
            c.moveToFirst();
        }

        Todo td = new Todo();
        td.setId(c.getInt(c.getColumnIndex(KEY_ID)));
        td.setContent((c.getString(c.getColumnIndex(KEY_CONTENT))));
        td.setStatus((c.getInt(c.getColumnIndex(KEY_STATUS))));

        return td;
    }

    public ArrayList<Todo> fetchAllToDos() {
        ArrayList<Todo> todos = new ArrayList<Todo>();
        String selectQuery = "SELECT  * FROM " + TABLE_TODO;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);

        if (c.moveToFirst()) {
            do {
                Todo td = new Todo();
                td.setId(c.getInt((c.getColumnIndex(KEY_ID))));
                td.setContent((c.getString(c.getColumnIndex(KEY_CONTENT))));

                todos.add(td);
            } while (c.moveToNext());
        }

        return todos;
    }

    public ArrayList<Todo> fetchAllToDosByDate(String date) {
        ArrayList<Todo> todos = new ArrayList<Todo>();

        String selectQuery = "SELECT  * FROM " + TABLE_TODO + " td, "
                + TABLE_DATE + " tg, " + TABLE_TODO_DATE + " tt WHERE tg."
                + KEY_DATE_NAME + " = '" + date + "'" + " AND tg." + KEY_ID
                + " = " + "tt." + KEY_DATE_ID + " AND td." + KEY_ID + " = "
                + "tt." + KEY_TODO_ID;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);

        if (c.moveToFirst()) {
            do {
                Todo td = new Todo();
                td.setId(c.getInt((c.getColumnIndex(KEY_ID))));
                td.setContent((c.getString(c.getColumnIndex(KEY_CONTENT))));
                td.setStatus((c.getInt(c.getColumnIndex(KEY_STATUS))));
                todos.add(td);
            } while (c.moveToNext());
        }

        return todos;
    }

    public int updateToDo(Todo todo) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_CONTENT, todo.getContent());
        values.put(KEY_STATUS, todo.getStatus());

        return db.update(TABLE_TODO, values, KEY_ID + " = ?",
                new String[] { String.valueOf(todo.getId()) });
    }

    public void deleteToDo(long todo_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_TODO, KEY_ID + " = ?",
                new String[] { String.valueOf(todo_id) });
        db.delete(TABLE_TODO_DATE, KEY_TODO_ID + " = ?",
                new String[] { String.valueOf(todo_id) });
    }


    public long createDate(Todo_Date date) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_DATE_NAME, date.getDate());

        ArrayList<Todo_Date> tmp = fetchAllDates();
        for (Todo_Date d : tmp) {
            if (d.getDate().equals(date.getDate())) return d.getId();
        }

        long date_id = db.insert(TABLE_DATE, null, values);

        return date_id;
    }

    public ArrayList<Todo_Date> fetchAllDates() {
        ArrayList<Todo_Date> dates = new ArrayList<Todo_Date>();
        String selectQuery = "SELECT  * FROM " + TABLE_DATE;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);

        if (c.moveToFirst()) {
            do {
                Todo_Date t = new Todo_Date();
                t.setId(c.getInt((c.getColumnIndex(KEY_ID))));
                t.setDate(c.getString(c.getColumnIndex(KEY_DATE_NAME)));

                dates.add(t);
            } while (c.moveToNext());
        }
        return dates;
    }
    public Todo_Date fetchDate(long id) {
        SQLiteDatabase db = this.getReadableDatabase();

        int dateId;
        Todo_Date date = new Todo_Date();
        String selectQuery = "SELECT  * FROM " + TABLE_TODO_DATE + " WHERE "
                + KEY_TODO_ID + " = " + id;

        Cursor c = db.rawQuery(selectQuery, null);

        if (c.moveToFirst()) {
            dateId = c.getInt((c.getColumnIndex(KEY_DATE_ID)));
            selectQuery = "SELECT  * FROM " + TABLE_DATE + " WHERE "
                    + KEY_ID + " = " + dateId;
            Cursor cDate = db.rawQuery(selectQuery, null);
            if (cDate.moveToFirst()) {
                date.setId(cDate.getInt(cDate.getColumnIndex(KEY_ID)));
                date.setDate(cDate.getString(cDate.getColumnIndex(KEY_DATE_NAME)));
            }
        }

        return date;
    }

    public int updateDate(Todo_Date date) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_DATE_NAME, date.getDate());

        return db.update(TABLE_DATE, values, KEY_ID + " = ?",
                new String[] { String.valueOf(date.getId()) });
    }

    public void deleteDate(Todo_Date date) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_DATE, KEY_ID + " = ?",
                new String[] { String.valueOf(date.getId()) });
    }

    public long createTodoDate(long todo_id, long date_id) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_TODO_ID, todo_id);
        values.put(KEY_DATE_ID, date_id);

        long id = db.insert(TABLE_TODO_DATE, null, values);

        return id;
    }

    public int updateTodoDate(long id, long date_id) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_DATE_ID, date_id);

        return db.update(TABLE_TODO, values, KEY_ID + " = ?",
                new String[] { String.valueOf(id) });
    }

    public long getDateId(long id) {
        SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT  * FROM " + TABLE_TODO_DATE + " WHERE "
                + KEY_TODO_ID + " = " + id;

        Cursor c = db.rawQuery(selectQuery, null);

        if (c != null) {
            c.moveToFirst();
        }

        return c.getInt(c.getColumnIndex(KEY_DATE_ID));
    }

    public boolean hasTodo(Todo_Date date) {
        SQLiteDatabase db = this.getReadableDatabase();
        int id = date.getId();

        String selectQuery = "SELECT  * FROM " + TABLE_TODO_DATE + " WHERE "
                + KEY_DATE_ID + " = " + id;

        Cursor c = db.rawQuery(selectQuery, null);

        if (c.moveToFirst()) return true;
        return false;
    }
}
