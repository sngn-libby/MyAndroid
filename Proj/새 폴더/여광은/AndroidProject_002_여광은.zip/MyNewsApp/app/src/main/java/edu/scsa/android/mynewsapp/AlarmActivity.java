package edu.scsa.android.mynewsapp;

import android.app.AlarmManager;
        import android.app.PendingIntent;
        import android.content.Context;
        import android.content.Intent;
        import android.support.annotation.Nullable;
        import android.support.design.widget.FloatingActionButton;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.util.Log;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
        import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
        import android.widget.ListView;
        import android.widget.Switch;
        import android.widget.TextView;
        import android.widget.Toast;
        import java.io.FileInputStream;
        import java.io.FileOutputStream;
        import java.io.IOException;
        import java.io.ObjectInputStream;
        import java.io.ObjectOutputStream;
        import java.util.ArrayList;

public class AlarmActivity extends AppCompatActivity {

    public static final int SET_ALARM = 1;
    public static final int EDIT_ALARM = 2;
    public static final int DELETE_ALARM = 3;

    ListView alarmListV;
    FloatingActionButton addFab;
    AlarmManager am;
    AlarmAdapter alarmA;
    ArrayList<Alarm> alarmArr;
    ArrayList<Boolean> isChecked;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm);

        am = (AlarmManager)getSystemService(ALARM_SERVICE);

        alarmListV = findViewById(R.id.alarmListV);
        addFab = findViewById(R.id.addFab);

        alarmArr = new ArrayList<Alarm>();
        isChecked = new ArrayList<Boolean>();

        try {
            FileInputStream fis = this.openFileInput("alarm.txt");
            ObjectInputStream is = new ObjectInputStream(fis);
            alarmArr = (ArrayList<Alarm>) is.readObject();
            is.close();
            fis.close();
            fis = this.openFileInput("is_checked.txt");
            is = new ObjectInputStream(fis);
            isChecked = (ArrayList<Boolean>) is.readObject();
            is.close();
            fis.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        alarmA = new AlarmAdapter(R.layout.alarm_layout, alarmArr);
        alarmListV.setAdapter(alarmA);
        registerForContextMenu(alarmListV);

        addFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent("com.scsa.android.action.SET_ALARM");
                startActivityForResult(i, SET_ALARM);
            }
        });

        alarmListV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Alarm myAlarm = (Alarm) parent.getAdapter().getItem(position);
                Intent i = new Intent("com.scsa.android.action.EDIT_ALARM");
                Bundle extras = new Bundle();
                extras.putInt("editIdx", position);
                extras.putSerializable("editAlarm", myAlarm);
                i.putExtras(extras);
                startActivityForResult(i, EDIT_ALARM);
            }
        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(0, DELETE_ALARM, 100, "삭제");
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info= (AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
        int index= info.position;

        switch (item.getItemId()) {
            case DELETE_ALARM:
                if (isChecked.get(index)) {
                    Intent i = new Intent(AlarmActivity.this, AlarmReceiver.class);
                    PendingIntent pi=PendingIntent.getBroadcast(AlarmActivity.this, index, i, PendingIntent.FLAG_CANCEL_CURRENT);
                    am.cancel(pi);
                }
                alarmArr.remove(index);
                isChecked.remove(index);
                Toast.makeText(this, "알람이 삭제됐습니다", Toast.LENGTH_SHORT).show();
                alarmA.notifyDataSetChanged();
                break;
            default:
                break;
        }
        return super.onContextItemSelected(item);
    }

    @Override
    protected void onStop() {
        super.onStop();
        try {
            FileOutputStream fos = this.openFileOutput("alarm.txt", Context.MODE_PRIVATE);
            ObjectOutputStream os = new ObjectOutputStream(fos);
            os.writeObject(alarmArr);
            os.close();
            fos.close();
            fos = this.openFileOutput("is_checked.txt", Context.MODE_PRIVATE);
            os = new ObjectOutputStream(fos);
            os.writeObject(isChecked);
            os.close();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch(requestCode) {
            case SET_ALARM:
                if (resultCode == RESULT_OK) {
                    Alarm newAlarm = (Alarm) data.getSerializableExtra("newAlarm");
                    alarmArr.add(newAlarm);
                    isChecked.add(true);
                    alarmA.notifyDataSetChanged();
                    Toast.makeText(this, "알람이 설정됐습니다", Toast.LENGTH_SHORT).show();
                }
                break;
            case EDIT_ALARM:
                if (resultCode == RESULT_OK) {
                    Alarm newAlarm = (Alarm) data.getExtras().getSerializable("newAlarm");
                    int idx = data.getExtras().getInt("editIdx");
                    alarmArr.set(idx, newAlarm);
                    alarmA.notifyDataSetChanged();

                    if (isChecked.get(idx)) {
                        long atTime = newAlarm.getTimeInMillis();
                        Intent i = new Intent();
                        i.setClass(AlarmActivity.this, AlarmReceiver.class);
                        PendingIntent pi = PendingIntent.getBroadcast(AlarmActivity.this, idx, i, PendingIntent.FLAG_CANCEL_CURRENT);
                        am.cancel(pi);
                        am.set(AlarmManager.RTC_WAKEUP, atTime, pi);
                    }

                    Toast.makeText(this, "알람이 수정됐습니다", Toast.LENGTH_SHORT).show();
                }
                break;
            default:
                break;
        }
    }

    class AlarmAdapter<A> extends BaseAdapter {

        ViewHolder holder;
        private int rowLayout;
        private ArrayList<Alarm> alarmList;

        public AlarmAdapter(int rowLayout, ArrayList<Alarm> alarmList) {
            this.rowLayout = rowLayout;
            this.alarmList = alarmList;
        }

        @Override
        public int getCount() {
            return alarmList.size();
        }

        @Override
        public Object getItem(int position) {
            return alarmList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = View.inflate(AlarmActivity.this, rowLayout, null);
                holder = new ViewHolder();
                holder.ampmTv = convertView.findViewById(R.id.ampmTv);
                holder.timeTv = convertView.findViewById(R.id.timeTv);
                holder.dateTv = convertView.findViewById(R.id.alarmDateTv);
                holder.alarmSw = convertView.findViewById(R.id.alarmSw);
                convertView.setTag(holder);

                holder.alarmSw.setChecked(isChecked.get(position));
                if (isChecked.get(position)) {
                    long atTime = ((Alarm)getItem(position)).getTimeInMillis();
                    Intent i = new Intent(AlarmActivity.this, AlarmReceiver.class);
                    PendingIntent pi = PendingIntent.getBroadcast(AlarmActivity.this, position, i, PendingIntent.FLAG_CANCEL_CURRENT);
                    am.set(AlarmManager.RTC_WAKEUP, atTime, pi);
                    Log.d("INFO", "alarm set initial: "+position);
                }
            }
            else {
                holder = (ViewHolder) convertView.getTag();
            }

            final Alarm selAlarm = (Alarm) getItem(position);
            final int index = position;

            holder.ampmTv.setText(selAlarm.getAmPm());
            int hour = (selAlarm.getHour() > 12) ? selAlarm.getHour()-12 : selAlarm.getHour();
            String min = (selAlarm.getMin() >= 10) ? selAlarm.getMin()+"" : "0"+selAlarm.getMin();
            holder.timeTv.setText(hour+":"+min);

            String month=(selAlarm.getMonth() < 10) ? "0"+selAlarm.getMonth() : ""+selAlarm.getMonth();
            String day=(selAlarm.getDay() < 10) ? "0"+selAlarm.getDay() : ""+selAlarm.getDay();
            holder.dateTv.setText(selAlarm.getYear()+"년 "+month+"월 "+day+"일");

            holder.alarmSw.setChecked(isChecked.get(position));
            holder.alarmSw.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isChecked.get(index).equals(true)) {
                        isChecked.set(index, false);
                        holder.alarmSw.setChecked(false);

                        Intent i = new Intent(AlarmActivity.this, AlarmReceiver.class);
                        PendingIntent pi=PendingIntent.getBroadcast(AlarmActivity.this, index, i, PendingIntent.FLAG_CANCEL_CURRENT);
                        Toast.makeText(AlarmActivity.this, "알람 해제", Toast.LENGTH_SHORT).show();
                        Log.d("INFO", "alarm canceled: "+index);
                        am.cancel(pi);
                    }
                    else {
                        isChecked.set(index, true);
                        holder.alarmSw.setChecked(true);

                        long atTime = selAlarm.getTimeInMillis();
                        Intent i = new Intent(AlarmActivity.this, AlarmReceiver.class);
                        PendingIntent pi = PendingIntent.getBroadcast(AlarmActivity.this, index, i, PendingIntent.FLAG_CANCEL_CURRENT);
                        am.set(AlarmManager.RTC_WAKEUP, atTime, pi);
                        Log.d("INFO", "alarm set: "+index);
                        Toast.makeText(AlarmActivity.this, "알람 등록", Toast.LENGTH_SHORT).show();
                    }
                }
            });

            return convertView;
        }

        class ViewHolder {
            TextView ampmTv;
            TextView timeTv;
            TextView dateTv;
            Switch alarmSw;
        }
    }
}
