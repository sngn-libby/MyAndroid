package edu.scsa.android.mynewsapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TimePicker;

import java.util.Calendar;

public class AlarmSetActivity extends AppCompatActivity {

    boolean isEdit;
    int editIdx;
    Button addBut;
    Button cancelBut;
    DatePicker datePick;
    TimePicker timePick;
    Alarm myAlarm;
    Calendar cal = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm_set);

        addBut = findViewById(R.id.addAlarmBut);
        cancelBut = findViewById(R.id.cancelAlarmBut);
        datePick = findViewById(R.id.datePick);
        timePick = findViewById(R.id.timePick);

        Intent i = getIntent();
        switch (i.getAction()) {
            case "com.scsa.android.action.SET_ALARM" :
                isEdit = false;
                myAlarm = new Alarm(cal.get(Calendar.YEAR),
                        cal.get(Calendar.MONTH)+1,
                        cal.get(Calendar.DAY_OF_MONTH),
                        cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE));
                break;
            case "com.scsa.android.action.EDIT_ALARM":
                isEdit = true;
                myAlarm = (Alarm) i.getExtras().getSerializable("editAlarm");
                editIdx = i.getExtras().getInt("editIdx");
                break;
        }

        datePick.init(myAlarm.getYear(),
                myAlarm.getMonth()-1,
                myAlarm.getDay(),
                new DatePicker.OnDateChangedListener() {
                    @Override
                    public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        myAlarm.setYear(year);
                        myAlarm.setMonth(monthOfYear+1);
                        myAlarm.setDay(dayOfMonth);
                    }
                }
        );

        timePick.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                myAlarm.setHour(hourOfDay);
                myAlarm.setMin(minute);
            }
        });

        addBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                long setTime = myAlarm.getTimeInMillis();
                if (Calendar.getInstance().getTimeInMillis() >= setTime) {
                    Calendar cal = Calendar.getInstance();
                    cal.add(Calendar.DATE, 1);
                }
                if (isEdit) {
                    Bundle extras = new Bundle();
                    extras.putInt("editIdx", editIdx);
                    extras.putSerializable("newAlarm", myAlarm);
                }
                else {
                    i.putExtra("newAlarm", myAlarm);
                }
                setResult(RESULT_OK, i);
                finish();
            }
        });

        cancelBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_CANCELED);
                finish();
            }
        });
    }
}
