package edu.scsa.android.mynewsapp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.ListFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.view.SimpleDraweeView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class NewsFragment extends ListFragment {

    NewsAdapter<News> newsA;
    RequestQueue queue;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        queue = Volley.newRequestQueue(getContext());

        String category = getArguments().getString("CATEGORY");
        String newsAPI="https://newsapi.org/v2/top-headlines?country=kr&category=";
        String APIKey="&apiKey=f7431ddcf5904b608b3f7d04ea366d8c";

        Log.d("CATEGORY", category);

        getNews(newsAPI+category+APIKey);

        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        News selNews = (News) l.getItemAtPosition(position);
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(selNews.getUrl()));
        startActivity(i);

        super.onListItemClick(l, v, position, id);
    }

    public void getNews(String url) {
        // Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            ArrayList<News> newsList = new ArrayList<News>();

                            JSONObject jsonObj = new JSONObject(response);
                            Log.d("INFO", jsonObj.toString());
                            JSONArray jsonArr = jsonObj.getJSONArray("articles");
                            for (int i=0; i< jsonArr.length(); i++) {
                                JSONObject obj = jsonArr.getJSONObject(i);
                                Log.d("NEWS", obj.toString());
                                News newsData = new News();
                                newsData.setTitle(obj.getString("title"));
                                newsData.setContent(obj.getString("description"));
                                newsData.setUrl(obj.getString("url"));
                                newsData.setImg(obj.getString("urlToImage"));
                                String author = obj.getString("author");
                                if (author.equals("null")) author = "저자없음";
                                newsData.setAuthor(author);
                                newsData.setSource(obj.getJSONObject("source").getString("name"));

                                newsList.add(newsData);
                            }

                            newsA = new NewsAdapter(R.layout.news_layout, newsList);
                            setListAdapter(newsA);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        // Add the request to the RequestQueue.
        queue.add(stringRequest);
    }

    class NewsAdapter<N> extends BaseAdapter {

        private int rowLayout;
        private ArrayList<News> newsList;
        ViewHolder holder;

        public NewsAdapter(int rowLayout, ArrayList<News> newsList) {
            this.rowLayout = rowLayout;
            this.newsList = newsList;
            Fresco.initialize(getContext());
        }

        @Override
        public int getCount() {
            return newsList.size();
        }

        @Override
        public Object getItem(int position) {
            return newsList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = View.inflate(getContext(), rowLayout, null);
                holder = new ViewHolder();
                holder.title = convertView.findViewById(R.id.titleTv);
                holder.content = convertView.findViewById(R.id.contentTv);
                holder.author = convertView.findViewById(R.id.authorTv);
                holder.source = convertView.findViewById(R.id.sourceTv);
                holder.draweeView = convertView.findViewById(R.id.newsImg);
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }

            News selNews = (News) getItem(position);
            holder.title.setText(selNews.getTitle());
            holder.content.setText(selNews.getContent());
            holder.author.setText(selNews.getAuthor());
            holder.source.setText(selNews.getSource());

            Uri uri = Uri.parse(selNews.getImg());
            holder.draweeView.setImageURI(uri);

            return convertView;
        }
    }

    class ViewHolder {
        TextView title;
        TextView content;
        TextView author;
        TextView source;
        SimpleDraweeView draweeView;
    }
}
