package edu.scsa.android.mynewsapp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.ListFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.view.SimpleDraweeView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SearchFragment extends Fragment {

    ListView resListV;
    EditText searchEt;
    Button enterBut;
    ArrayList<News> newsArr;
    NewsAdapter<News> newsA;
    RequestQueue queue;

    String clientId = "FOXC0P2I7RZEKQxZnuTV";
    String clientSecret = "F5zSdKl6i9";


    public SearchFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        queue = Volley.newRequestQueue(getContext());

        View v = inflater.inflate(R.layout.fragment_search, container, false);
        resListV = v.findViewById(R.id.searchResListV);
        searchEt = v.findViewById(R.id.searchInputTv);

        resListV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                News selNews = (News) parent.getAdapter().getItem(position);
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(selNews.getUrl()));
                startActivity(i);
            }
        });

        enterBut = v.findViewById(R.id.searchEnterBut);
        enterBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    String text = null;
                    text = URLEncoder.encode(searchEt.getText().toString(), "UTF-8");
                    String apiURL = "https://openapi.naver.com/v1/search/news?query="+ text;

                    Log.d("INFO", "///////button clicked");
                    Log.d("INFO", text);

                    getNews(apiURL);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        return v;
    }

    public void getNews(String url) {
        // Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            ArrayList<News> newsList = new ArrayList<News>();

                            JSONObject jsonObj = new JSONObject(response);
                            Log.d("INFO", jsonObj.toString());
                            JSONArray jsonArr = jsonObj.getJSONArray("items");
                            for (int i=0; i< jsonArr.length(); i++) {
                                JSONObject obj = jsonArr.getJSONObject(i);
                                News newsData = new News();
                                newsData.setTitle(obj.getString("title"));
                                newsData.setContent(obj.getString("description"));
                                newsData.setUrl(obj.getString("link"));

                                newsList.add(newsData);
                            }

                            newsA = new NewsAdapter(R.layout.search_layout, newsList);
                            resListV.setAdapter(newsA);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap();
                params.put("X-Naver-Client-Id", clientId);
                params.put("X-Naver-Client-Secret", clientSecret);
                Log.d("getHedaer =>", ""+ params);
                return params;
            }
        };

        // Add the request to the RequestQueue.
        queue.add(stringRequest);
    }

    class NewsAdapter<N> extends BaseAdapter {

        private int rowLayout;
        private ArrayList<News> newsList;
        ViewHolder holder;

        public NewsAdapter(int rowLayout, ArrayList<News> newsList) {
            this.rowLayout = rowLayout;
            this.newsList = newsList;
            Fresco.initialize(getContext());
        }

        @Override
        public int getCount() {
            return newsList.size();
        }

        @Override
        public Object getItem(int position) {
            return newsList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = View.inflate(getContext(), rowLayout, null);
                holder = new ViewHolder();
                holder.title = convertView.findViewById(R.id.searchTitleTv);
                holder.content = convertView.findViewById(R.id.searchConTv);
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }

            News selNews = (News) getItem(position);
            holder.title.setText(selNews.getTitle());
            holder.content.setText(selNews.getContent());

            return convertView;
        }

        class ViewHolder {
            TextView title;
            TextView content;
        }
    }
}