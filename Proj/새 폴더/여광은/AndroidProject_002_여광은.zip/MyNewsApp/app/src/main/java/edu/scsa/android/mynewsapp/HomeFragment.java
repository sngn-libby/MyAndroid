package edu.scsa.android.mynewsapp;


import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class HomeFragment extends Fragment {

    String cityname;

    Geocoder geocoder;
    private LocationManager locationManager;
    private static final int REQUEST_CODE_LOCATION = 2;

    TextView dateTv;
    TextView dayTv;
    TextView weatherTv;
    TextView locTv;

    RequestQueue queue;


    public HomeFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_home, container,false);
        dateTv=v.findViewById(R.id.homeDateTv);
        dayTv=v.findViewById(R.id.homeDayTv);
        weatherTv=v.findViewById(R.id.homeWeatherTv);
        locTv=v.findViewById(R.id.homeLocTv);

        queue = Volley.newRequestQueue(getContext());

        Calendar cal = Calendar.getInstance();
        String dayarr[] = {"일", "월", "화", "수", "목", "금", "토"};
        int month = cal.get(Calendar.MONTH)+1;
        int date = cal.get(Calendar.DAY_OF_MONTH);
        int day = cal.get(Calendar.DAY_OF_WEEK);

        if (cal.get(Calendar.HOUR_OF_DAY) >= 5 && cal.get(Calendar.HOUR_OF_DAY) <= 17) {
            v.setBackgroundResource(R.drawable.city_day);
        }
        else {
            v.setBackgroundResource(R.drawable.city_night);
        }

        dateTv.setText(month+"월 "+date+"일");
        dayTv.setText(dayarr[day-1]+"요일");

        return v;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        //사용자의 위치 수신을 위한 세팅
        locationManager = (LocationManager)getContext().getSystemService(Context.LOCATION_SERVICE);
        //사용자의 현재 위치
        Location userLocation = getMyLocation();
        if( userLocation != null ) {
            try {
                double latitude = userLocation.getLatitude();
                double longitude = userLocation.getLongitude();

                geocoder = new Geocoder(getContext());
                List<Address> addressList = geocoder.getFromLocation(latitude, longitude, 1);
                cityname = addressList.get(0).getAdminArea();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        locTv.setText(cityname);
        String Api = "http://api.openweathermap.org/data/2.5/weather?q="+cityname+"&appid=30734c5d114e0a67709c4dc2c8090858";
        getWeather(Api);

    }

    private Location getMyLocation() {
        Location currentLocation = null;
        // Register the listener with the Location Manager to receive location updates
        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, this.REQUEST_CODE_LOCATION);
            getMyLocation();
        }
        else {
            // 수동으로 위치 구하기
            currentLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (currentLocation == null) currentLocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

            if (currentLocation != null) {
                double lng = currentLocation.getLongitude();
                double lat = currentLocation.getLatitude();
            }
        }

        return currentLocation;
    }

    public void getWeather(String url) {
        // Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONObject jsonObj = new JSONObject(response);
                            Log.d("INFO", jsonObj.toString());

                            JSONArray jsonArr = jsonObj.getJSONArray("weather");

                            JSONObject obj = (JSONObject) jsonArr.get(0);
                            Log.d("INFO", obj.getString("main"));
                            String weather = obj.getString("description");

                            obj = jsonObj.getJSONObject("main");
                            double temp = obj.getDouble("temp") - 273.0;
                            int temperature = (int) temp;

                            weatherTv.setText(temperature+"도, "+weather);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        // Add the request to the RequestQueue.
        queue.add(stringRequest);
    }

}
