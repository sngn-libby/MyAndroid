package edu.scsa.android.mynewsapp;

import java.util.Random;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

public class NewsCatchActivity extends Activity {
    FrameLayout f;
    FrameLayout.LayoutParams params;

    int count=0;
    int delay=1200;
    int delay_diff=300;
    static boolean threadEndFlag=true;

    NewsTask nt;
    SojuTask st;

    int myWidth;  // 내 폰의 너비
    int myHeight; // 내 폰의 높이
    int imgWidth=150;  //그림 크기
    int imgHeight=150;//그림 크기
    Random r=new Random();

    SoundPool pool;
    int goodSound;
    int sadSound;
    MediaPlayer mp;

    int x=200;        //시작위치
    int y=200;        //시작위치

    ImageView[] news_imgs;
    ImageView[] soju_imgs;

    int level=1;
    int nums=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_catch);
        f=(FrameLayout) findViewById(R.id.frame_game);
        params=new FrameLayout.LayoutParams(1, 1);

        //디스플레이 크기 체크
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        myWidth=metrics.widthPixels;
        myHeight=metrics.heightPixels;
        Log.d("game","My Window "+myWidth+" : "+myHeight);

        //사운드 셋팅
        pool = new SoundPool(1, AudioManager.STREAM_MUSIC, 0);
        goodSound = pool.load(this, R.raw.crowd_applause, 1);
        sadSound = pool.load(this, R.raw.sad_trombone, 1);
        mp=MediaPlayer.create(this, R.raw.studysong);
        mp.setLooping(true);

        init(5);
    }

    public void init(int nums){
        //초기화
        count=0;
        threadEndFlag=true;
        this.nums=nums;
        delay=(int)(delay*(10-level)/10.);

        f.removeAllViews();

        Toast.makeText(this, "Level " + level, Toast.LENGTH_SHORT).show();

        //이미지 담을 배열 생성과 이미지 담기
        news_imgs=new ImageView[nums];
        for(int i=0; i<nums; i++){
            ImageView iv=new ImageView(this);
            iv.setImageResource(R.drawable.newspaper);  // 이미지 소스 설정
            f.addView(iv, params);  // 화면에 표시
            news_imgs[i]=iv;     // 배열에 담기
            iv.setOnClickListener(news_clicked);  // 이벤트 등록
        }

        soju_imgs=new ImageView[nums / 2];
        for(int i=0; i<nums/2; i++){
            ImageView iv=new ImageView(this);
            iv.setImageResource(R.drawable.soju_bottle);  // 이미지 소스 설정
            f.addView(iv, params);  // 화면에 표시
            soju_imgs[i]=iv;     // 배열에 담기
            iv.setOnClickListener(soju_clicked);  // 이벤트 등록
        }

        nt=new NewsTask();
        nt.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

        st = new SojuTask();
        st.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
    }

    protected void onResume() {
        super.onResume();
        mp.start();
    };
    protected void onPause() {
        super.onPause();
        mp.stop();
    };

    protected void onDestroy() {
        super.onDestroy();
        mp.release();
        nt.cancel(true);
        st.cancel(true);
        threadEndFlag = false;
    };


    View.OnClickListener  news_clicked=new View.OnClickListener() {
        public void onClick(View v) {   // 신문을 클릭했을 때
            count++;
            ImageView iv=(ImageView)v;
            pool.play(goodSound, 1, 1, 0, 0, 1);  // 소리 내기
            iv.setVisibility(View.INVISIBLE);          // 이미지 제거

            Toast.makeText(NewsCatchActivity.this, "지식이 증가했습니다: "+count, Toast.LENGTH_LONG).show();
            if(count==nums){   // 쥐를 다 잡았을때
                threadEndFlag=false;
                nt.cancel(true);
                st.cancel(true);

                AlertDialog.Builder dia=new AlertDialog.Builder(NewsCatchActivity.this);
                dia.setMessage("레벨"+level+" 클리어! 계속하시겠습니까?");
                dia.setPositiveButton("네", new OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        level++;
                        delay -= 100;
                        init(6);
                    }
                });
                dia.setNegativeButton("아니오", new OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                });
                dia.show();
            }
        }
    };

    View.OnClickListener  soju_clicked=new View.OnClickListener() {
        public void onClick(View v) {
            ImageView iv=(ImageView)v;
            pool.play(sadSound, 1, 1, 0, 0, 1);  // 소리 내기
            iv.setVisibility(View.INVISIBLE);

            Toast.makeText(NewsCatchActivity.this, "실패했습니다", Toast.LENGTH_LONG).show();
            threadEndFlag=false;
            nt.cancel(true);
            st.cancel(true);

            AlertDialog.Builder dia=new AlertDialog.Builder(NewsCatchActivity.this);
            dia.setMessage("레벨"+level+" 실패! 다시 하시겠습니까?");
            dia.setPositiveButton("네", new OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    init(5);
                }
            });
            dia.setNegativeButton("아니오", new OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });
            dia.show();
        }
    };


    public void update(ImageView[] imgs){
        if(!threadEndFlag) return;
        for(ImageView img:imgs){
            x=r.nextInt(myWidth-imgWidth);
            y=r.nextInt(myHeight-imgHeight);

            img.layout(x, y, x+imgWidth, y+imgHeight);
            img.invalidate();
        }

    }

    class NewsTask extends AsyncTask<Void, Void, Void>{
        @Override
        protected Void doInBackground(Void... params) {// 다른 쓰레드
            while(threadEndFlag){
                publishProgress();
                try {
                    Thread.sleep(delay);
                } catch (InterruptedException e) {e.printStackTrace();}
            }
            return null;
        }
        @Override
        protected void onProgressUpdate(Void... values) {
            update(news_imgs);
        }
    };

    class SojuTask extends AsyncTask<Void, Void, Void>{
        @Override
        protected Void doInBackground(Void... params) {// 다른 쓰레드
            while(threadEndFlag){
                publishProgress();
                try {
                    Thread.sleep(delay+delay_diff);
                } catch (InterruptedException e) {e.printStackTrace();}
            }
            return null;
        }
        @Override
        protected void onProgressUpdate(Void... values) {
            update(soju_imgs);
        }
    };

}// end MainActivity