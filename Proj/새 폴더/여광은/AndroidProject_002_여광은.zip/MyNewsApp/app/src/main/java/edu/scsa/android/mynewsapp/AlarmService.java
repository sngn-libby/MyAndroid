package edu.scsa.android.mynewsapp;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;

public class AlarmService extends Service {

    private NotificationManager nm;
    MediaPlayer mp;

    public AlarmService() {
    }

    @Override
    public void onCreate() {
        nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        mp = MediaPlayer.create(this, R.raw.crowd_applause);
        Log.d("INFO", "onCreate...");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        showNoti();
        Log.d("INFO", "onStartCommand...");
        return super.onStartCommand(intent, flags, startId);
    }

    private void showNoti() {
        Notification.Builder b = new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.star_big_on);

        b.setContentTitle("MyNewsApp Notification");
        b.setContentText("alarm test!!!!!!!!");

        b.setDefaults(Notification.DEFAULT_ALL);
        b.setPriority(Notification.PRIORITY_HIGH);
        b.setVisibility(Notification.VISIBILITY_PUBLIC);

        Toast.makeText(this, "ALARM 울림", Toast.LENGTH_SHORT).show();
        nm.notify(100, b.build());
        mp.start();
    }

    @Override
    public void onDestroy() {
        Log.d("INFO", "onDestroy...");
        nm.cancel(100);
        mp.stop();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

}
